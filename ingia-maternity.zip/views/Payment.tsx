
import React, { useState } from 'react';
import { UserProfile, Screen } from '../types';
import { Smartphone, CreditCard, ShieldCheck, Check } from 'lucide-react';

const Payment: React.FC<{ user: UserProfile, navigate: (s: Screen) => void }> = ({ user, navigate }) => {
  const [selectedMethod, setSelectedMethod] = useState<'M-PESA' | 'TIGO' | 'AIRTEL' | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handlePay = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
    }, 2000);
  };

  if (isSuccess) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center space-y-6 animate-fadeIn">
        <div className="w-24 h-24 bg-[#B7E4C7] rounded-full flex items-center justify-center text-white shadow-lg animate-bounce">
          <Check size={48} strokeWidth={4} />
        </div>
        <div>
          <h2 className="text-2xl font-bold">Payment Successful!</h2>
          <p className="text-sm opacity-60 max-w-[200px] mx-auto mt-2">Your consultation booking is confirmed. Check your SMS for receipt.</p>
        </div>
        <button 
          onClick={() => navigate(Screen.CONSULTATION)}
          className="bg-[#F7B7A3] text-white px-8 py-4 rounded-full font-bold shadow-md"
        >
          Go to Consultation
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fadeIn">
      <h2 className="text-2xl font-bold">Secure Payment</h2>

      <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-[#A8C3B1]/20">
        <div className="flex justify-between items-center mb-6">
          <span className="text-xs font-bold uppercase text-[#A8C3B1] tracking-widest">Selected Service</span>
          <span className="bg-[#F3C6CF]/20 text-[#3E3E3E] px-3 py-1 rounded-full text-[10px] font-bold">PREMIUM CARE</span>
        </div>
        <div className="flex justify-between items-end">
          <div>
            <h3 className="text-xl font-bold">Doctor Consultation</h3>
            <p className="text-[11px] opacity-60">Unlimited chat for 1 month</p>
          </div>
          <p className="text-2xl font-bold text-[#3E3E3E]">Tsh 15,000</p>
        </div>
      </div>

      <section className="space-y-4">
        <h3 className="text-sm font-bold uppercase text-[#A8C3B1]">Payment Method</h3>
        <div className="grid grid-cols-3 gap-3">
          {[
            { id: 'M-PESA', label: 'M-Pesa', color: 'bg-red-500' },
            { id: 'TIGO', label: 'Tigo Pesa', color: 'bg-blue-600' },
            { id: 'AIRTEL', label: 'Airtel Money', color: 'bg-red-600' }
          ].map(method => (
            <button 
              key={method.id}
              onClick={() => setSelectedMethod(method.id as any)}
              className={`p-4 rounded-3xl flex flex-col items-center gap-2 border-2 transition-all shadow-sm ${
                selectedMethod === method.id ? 'border-[#F7B7A3] bg-[#F7B7A3]/10' : 'border-white bg-white/60'
              }`}
            >
              <Smartphone size={24} className={selectedMethod === method.id ? 'text-[#F7B7A3]' : 'opacity-40'} />
              <span className="text-[9px] font-bold uppercase">{method.label}</span>
            </button>
          ))}
        </div>
      </section>

      <div className="bg-[#E3F6E3] p-5 rounded-[2rem] flex items-center gap-4">
        <ShieldCheck size={32} className="text-[#A8C3B1]" />
        <p className="text-[11px] leading-tight">Your payment is encrypted and secured by mobile money providers. No credit card required.</p>
      </div>

      <button 
        disabled={!selectedMethod || isProcessing}
        onClick={handlePay}
        className={`w-full p-5 rounded-[2rem] text-white font-bold text-lg shadow-lg flex items-center justify-center gap-3 transition-all ${
          selectedMethod && !isProcessing ? 'bg-[#F7B7A3] active:scale-95' : 'bg-gray-300 cursor-not-allowed'
        }`}
      >
        {isProcessing ? 'Processing...' : <>Confirm Payment <CreditCard size={20} /></>}
      </button>
    </div>
  );
};

export default Payment;
