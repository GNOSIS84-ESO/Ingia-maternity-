
import React from 'react';
import { UserPlus, LogIn, ChevronLeft } from 'lucide-react';
import Logo from '../components/Logo';

interface AuthChoiceProps {
  onSignIn: () => void;
  onSignUp: () => void;
  onBack: () => void;
  t: (key: string) => string;
}

const AuthChoice: React.FC<AuthChoiceProps> = ({ onSignIn, onSignUp, onBack, t }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full animate-fadeIn p-6">
      <button 
        onClick={onBack}
        className="absolute top-8 left-6 p-3 bg-white rounded-full shadow-sm text-[#3E3E3E] active:scale-90 transition-transform"
      >
        <ChevronLeft size={20} />
      </button>

      <div className="mb-12 flex flex-col items-center">
        <Logo size="md" className="mb-6" />
        <h1 className="text-3xl font-bold text-[#3E3E3E]">Mama's Care</h1>
        <p className="text-sm opacity-60 italic">Secure & Personalized</p>
      </div>

      <div className="w-full space-y-4">
        <button 
          onClick={onSignIn}
          className="w-full bg-white p-6 rounded-[2.5rem] shadow-sm flex items-center gap-4 transition-all hover:scale-[1.02] active:scale-[0.98] border-2 border-transparent hover:border-[#A8C3B1]"
        >
          <div className="w-14 h-14 bg-[#B7E4C7] rounded-2xl flex items-center justify-center text-white">
            <LogIn size={28} />
          </div>
          <div className="text-left">
            <span className="block text-lg font-bold text-[#3E3E3E]">{t('sign_in')}</span>
            <span className="text-[10px] text-[#3E3E3E]/40 uppercase font-bold tracking-widest">Access your profile</span>
          </div>
        </button>

        <button 
          onClick={onSignUp}
          className="w-full bg-[#E3F6E3]/60 p-6 rounded-[2.5rem] shadow-sm flex items-center gap-4 transition-all hover:scale-[1.02] active:scale-[0.98] border-2 border-white"
        >
          <div className="w-14 h-14 bg-[#F3C6CF] rounded-2xl flex items-center justify-center text-white">
            <UserPlus size={28} />
          </div>
          <div className="text-left">
            <span className="block text-lg font-bold text-[#3E3E3E]">{t('sign_up')}</span>
            <span className="text-[10px] text-[#3E3E3E]/40 uppercase font-bold tracking-widest">Create a new file</span>
          </div>
        </button>
      </div>
    </div>
  );
};

export default AuthChoice;
