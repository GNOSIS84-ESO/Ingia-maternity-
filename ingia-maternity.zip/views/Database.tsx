
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { UserProfile, AppContent } from '../types';
import { 
  Search, User, Phone, MapPin, Calendar, Heart, Trash2, X, ChevronRight, 
  Send, BellRing, Clock, Table, List, Download, Edit3, Save, Activity, 
  ShieldAlert, FileJson, UploadCloud, RefreshCw 
} from 'lucide-react';

interface DatabaseProps {
  t: (key: string) => string;
  user: UserProfile;
}

const Database: React.FC<DatabaseProps> = ({ t, user }) => {
  const [recipients, setRecipients] = useState<UserProfile[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRecipient, setSelectedRecipient] = useState<UserProfile | null>(null);
  const [showBroadcast, setShowBroadcast] = useState(false);
  const [broadcastMsg, setBroadcastMsg] = useState('');
  const [viewMode, setViewMode] = useState<'LIST' | 'DATASHEET'>('LIST');
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editFormData, setEditFormData] = useState<UserProfile | null>(null);
  const [showAdminTools, setShowAdminTools] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadDatabase();
    if (user.role === 'RECIPIENT') {
      const db = JSON.parse(localStorage.getItem('ingia_database') || '[]');
      const me = db.find((u: UserProfile) => u.phone === user.phone);
      if (me) setSelectedRecipient(me);
    }
  }, [user]);

  const loadDatabase = () => {
    setRecipients(JSON.parse(localStorage.getItem('ingia_database') || '[]'));
  };

  // Performance: Memoize filtered results to prevent expensive re-calc on every render
  const filteredRecipients = useMemo(() => {
    const term = searchTerm.toLowerCase();
    return recipients.filter(r => 
      r.name.toLowerCase().includes(term) || 
      r.phone.includes(term)
    );
  }, [recipients, searchTerm]);

  const deleteRecipient = (id: string) => {
    if (window.confirm("Permanent action: Delete this clinical file?")) {
      const updated = recipients.filter(r => r.id !== id);
      setRecipients(updated);
      localStorage.setItem('ingia_database', JSON.stringify(updated));
      setSelectedRecipient(null);
    }
  };

  const clearDatabase = () => {
    if (window.confirm("🚨 CRITICAL: Clear ALL records?") && window.prompt("Type 'DELETE ALL':") === 'DELETE ALL') {
      localStorage.setItem('ingia_database', '[]');
      setRecipients([]);
      alert("Database wiped.");
    }
  };

  const handleUpdateProfile = () => {
    if (!editFormData) return;
    const updated = { ...editFormData, updatedAt: new Date().toISOString() };
    const updatedDb = recipients.map(r => r.id === editFormData.id ? updated : r);
    setRecipients(updatedDb);
    localStorage.setItem('ingia_database', JSON.stringify(updatedDb));
    setSelectedRecipient(updated);
    setIsEditingProfile(false);
  };

  const exportToJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(recipients, null, 2));
    const anchor = document.createElement('a');
    anchor.setAttribute("href", dataStr);
    anchor.setAttribute("download", `ingia_backup_${new Date().toISOString().split('T')[0]}.json`);
    anchor.click();
    anchor.remove();
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const imported = JSON.parse(event.target?.result as string);
        if (Array.isArray(imported)) {
          const merged = [...recipients, ...imported];
          const unique = Array.from(new Map(merged.map(item => [item.id, item])).values());
          localStorage.setItem('ingia_database', JSON.stringify(unique));
          loadDatabase();
          alert("Import successful.");
        }
      } catch (err) { alert("Invalid file."); }
    };
    reader.readAsText(file);
  };

  const formatTimestamp = (iso?: string) => {
    if (!iso) return t('no_date_set');
    return new Date(iso).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  };

  if (user.role === 'RECIPIENT') {
    if (!selectedRecipient) return <div className="p-10 text-center opacity-40 font-bold">{t('notifying')}</div>;
    return (
      <div className="space-y-6 animate-fadeIn pb-4">
        <h2 className="text-2xl font-bold">{t('my_records')}</h2>
        <div className="bg-white p-8 rounded-[3rem] shadow-sm border border-[#A8C3B1]/20">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-[#F3C6CF] rounded-[1.5rem] flex items-center justify-center text-white"><User size={32} /></div>
              <div>
                <h3 className="text-xl font-bold">{selectedRecipient.name}</h3>
                <p className="text-xs text-[#A8C3B1] font-bold">Week {selectedRecipient.weeksPregnant}</p>
              </div>
            </div>
            <div className="space-y-4">
               <div className="bg-gray-50 p-5 rounded-3xl space-y-4">
                  <div className="flex justify-between items-center border-b pb-2"><span className="text-xs font-bold text-gray-400">Location</span><span className="text-xs font-bold">{selectedRecipient.location}</span></div>
                  <div className="flex justify-between items-center border-b pb-2"><span className="text-xs font-bold text-gray-400">Blood Group</span><span className="text-xs font-bold">{selectedRecipient.bloodGroup}</span></div>
                  <div className="flex justify-between items-center border-b pb-2"><span className="text-xs font-bold text-gray-400">LNMP</span><span className="text-xs font-bold">{selectedRecipient.lnmp}</span></div>
                  <div className="flex justify-between items-center border-b pb-2"><span className="text-xs font-bold text-gray-400">Emergency</span><span className="text-xs font-bold text-red-400">{selectedRecipient.emergencyContact}</span></div>
               </div>
               <div className="p-4 bg-[#E3F6E3] rounded-3xl">
                  <h4 className="text-[10px] font-bold uppercase text-[#A8C3B1] mb-2">Clinical Notes</h4>
                  <p className="text-xs italic text-gray-500">{localStorage.getItem('ingia_medical_notes') || 'No medical notes yet.'}</p>
               </div>
            </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fadeIn h-full flex flex-col pb-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{t('database')}</h2>
        <div className="flex gap-2">
          <button 
            onClick={() => setShowAdminTools(!showAdminTools)}
            className={`p-3 rounded-2xl shadow-sm transition-all ${showAdminTools ? 'bg-[#3E3E3E] text-white' : 'bg-white text-[#3E3E3E]'}`}
          >
            <RefreshCw size={20} className={showAdminTools ? 'animate-spin-slow' : ''} />
          </button>
          <button onClick={() => setShowBroadcast(true)} className="p-3 bg-[#F7B7A3] text-white rounded-2xl shadow-sm"><BellRing size={20} /></button>
        </div>
      </div>

      <div className="relative">
        <input 
          type="text"
          placeholder={t('search_recipients')}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full p-4 pl-12 bg-white rounded-2xl shadow-sm border border-gray-100 outline-none focus:ring-2 focus:ring-[#F7B7A3]"
        />
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={20} />
      </div>

      <div className="flex-1 overflow-y-auto space-y-3 pb-20">
        {filteredRecipients.map((r, i) => (
          <div key={i} onClick={() => { setSelectedRecipient(r); setEditFormData(r); }} className="bg-white p-4 rounded-3xl shadow-sm flex items-center gap-4 active:scale-[0.98] transition-all cursor-pointer border border-transparent hover:border-[#F3C6CF]">
            <div className="w-12 h-12 bg-[#E3F6E3] rounded-2xl flex items-center justify-center text-[#A8C3B1] font-bold">{r.name[0]}</div>
            <div className="flex-1">
              <h4 className="font-bold text-sm">{r.name}</h4>
              <p className="text-[9px] text-[#3E3E3E]/40 font-bold uppercase">{formatTimestamp(r.updatedAt || r.registrationDate)}</p>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-bold text-[#F7B7A3]">Week {r.weeksPregnant}</span>
              <ChevronRight size={16} className="text-gray-300 ml-auto" />
            </div>
          </div>
        ))}
        {filteredRecipients.length === 0 && (
          <div className="text-center py-10 opacity-30 text-xs font-bold">No results found</div>
        )}
      </div>

      {selectedRecipient && user.role === 'INSTRUCTOR' && (
        <div className="fixed inset-0 z-[120] bg-black/60 backdrop-blur-sm flex items-end animate-fadeIn">
          <div className="bg-white w-full h-[85vh] rounded-t-[3rem] overflow-y-auto p-8 shadow-2xl animate-slideInUp">
            <button onClick={() => { setSelectedRecipient(null); setIsEditingProfile(false); }} className="absolute right-8 top-8 p-2 bg-gray-100 rounded-full"><X size={20} /></button>
            <div className="flex items-center gap-4 mb-8 mt-4">
              <div className="w-16 h-16 bg-[#F3C6CF] rounded-[1.5rem] flex items-center justify-center text-white"><User size={32} /></div>
              <div><h3 className="text-2xl font-bold">{selectedRecipient.name}</h3><p className="text-xs text-[#A8C3B1] font-bold">Week {selectedRecipient.weeksPregnant}</p></div>
            </div>
            {isEditingProfile ? (
              <div className="space-y-4 pb-12">
                {['name', 'phone', 'location', 'emergencyContact'].map(field => (
                  <div key={field} className="bg-gray-50 p-3 rounded-2xl">
                    <label className="text-[9px] uppercase font-bold text-gray-400">{field}</label>
                    <input className="w-full bg-transparent outline-none font-bold text-sm" value={(editFormData as any)?.[field]} onChange={e => setEditFormData({...editFormData!, [field]: e.target.value})} />
                  </div>
                ))}
                <div className="flex gap-2">
                  <button onClick={() => setIsEditingProfile(false)} className="flex-1 bg-gray-100 p-4 rounded-2xl font-bold text-gray-500">Cancel</button>
                  <button onClick={handleUpdateProfile} className="flex-[2] bg-[#A8C3B1] text-white p-4 rounded-2xl font-bold shadow-md">Save Changes</button>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <button onClick={() => setIsEditingProfile(true)} className="w-full bg-[#E3F6E3] text-[#A8C3B1] p-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95"><Edit3 size={18} /> Modify File</button>
                <div className="bg-gray-50 p-5 rounded-3xl space-y-4">
                  <div className="flex justify-between border-b pb-2"><span className="text-xs">Location</span><span className="text-xs font-bold">{selectedRecipient.location}</span></div>
                  <div className="flex justify-between border-b pb-2"><span className="text-xs">Emergency</span><span className="text-xs font-bold text-red-400">{selectedRecipient.emergencyContact}</span></div>
                </div>
                <button onClick={() => deleteRecipient(selectedRecipient.id)} className="w-full text-red-500 text-xs font-bold uppercase py-4 border border-red-50 rounded-3xl hover:bg-red-50">Delete Recipient File</button>
              </div>
            )}
          </div>
        </div>
      )}

      {showBroadcast && (
        <div className="fixed inset-0 z-[150] bg-black/70 flex items-center justify-center p-6 animate-fadeIn">
          <div className="bg-white w-full max-w-sm rounded-[3rem] p-8 shadow-2xl space-y-6">
            <div className="flex justify-between items-center"><h3 className="text-xl font-bold">Alert Mothers</h3><button onClick={() => setShowBroadcast(false)}><X /></button></div>
            <textarea className="w-full bg-gray-50 p-4 rounded-2xl h-32 outline-none text-sm" value={broadcastMsg} onChange={e => setBroadcastMsg(e.target.value)} placeholder="Type alert message..." />
            <button onClick={() => { if(broadcastMsg.trim()) { alert("Broadcast sent."); setBroadcastMsg(''); setShowBroadcast(false); } }} className="w-full bg-[#F7B7A3] text-white p-4 rounded-3xl font-bold flex items-center justify-center gap-2 shadow-lg">Push Notification <Send size={18} /></button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Database;
