
import React, { useMemo } from 'react';
import { UserProfile, AppContent } from '../types';
import { ChevronLeft, Bell, Calendar, Star, Info } from 'lucide-react';

interface NotificationsProps {
  user: UserProfile;
  t: (key: string) => string;
  onBack: () => void;
}

const Notifications: React.FC<NotificationsProps> = ({ user, t, onBack }) => {
  const appContent: AppContent = useMemo(() => {
    const saved = localStorage.getItem('ingia_app_content');
    return saved ? JSON.parse(saved) : null;
  }, []);

  const greeting = useMemo(() => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return t('good_morning');
    if (hour >= 12 && hour < 17) return t('good_afternoon');
    if (hour >= 17 && hour < 21) return t('good_evening');
    return t('good_night');
  }, [t]);

  const timeAgo = (isoString: string) => {
    const date = new Date(isoString);
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 1000 / 60); // minutes
    if (diff < 1) return 'Just now';
    if (diff < 60) return `${diff}m ago`;
    const hours = Math.floor(diff / 60);
    if (hours < 24) return `${hours}h ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="space-y-6 animate-fadeIn h-full flex flex-col">
      <div className="flex items-center gap-4">
        <button 
          onClick={onBack}
          className="p-2 bg-white rounded-full shadow-sm text-[#3E3E3E] active:scale-90 transition-transform"
        >
          <ChevronLeft size={20} />
        </button>
        <h2 className="text-2xl font-bold">{t('notifications_center')}</h2>
      </div>

      <div className="bg-[#E3F6E3] p-6 rounded-[2.5rem] border border-white shadow-sm relative overflow-hidden">
        <div className="relative z-10 flex items-center gap-4">
          <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#A8C3B1] shadow-inner">
            <Star size={24} fill="#A8C3B1" />
          </div>
          <div>
            <h3 className="font-bold text-[#3E3E3E]">{greeting}</h3>
            <p className="text-[10px] opacity-60 uppercase font-bold tracking-widest">{user.name}</p>
          </div>
        </div>
        <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-white/20 rounded-full blur-2xl"></div>
      </div>

      <div className="flex-1 space-y-4 overflow-y-auto pr-1">
        {/* Instructor Global Notification */}
        {appContent?.globalNotification && (
          <div className="bg-white p-5 rounded-[2rem] shadow-sm border-l-4 border-[#F7B7A3] animate-slideInRight">
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center gap-2">
                <Bell size={16} className="text-[#F7B7A3]" />
                <span className="text-[10px] font-bold text-[#F7B7A3] uppercase tracking-wider">{t('from_instructor')}</span>
              </div>
              <span className="text-[9px] opacity-40 font-bold">{timeAgo(appContent.globalNotification.timestamp)}</span>
            </div>
            <p className="text-sm font-medium text-[#3E3E3E] leading-relaxed">
              {appContent.globalNotification.message}
            </p>
          </div>
        )}

        {/* Automatic Reminders (Simulated) */}
        <div className="bg-white/60 p-5 rounded-[2rem] shadow-sm border border-white">
          <div className="flex justify-between items-start mb-2">
            <div className="flex items-center gap-2">
              <Calendar size={16} className="text-[#A8C3B1]" />
              <span className="text-[10px] font-bold text-[#A8C3B1] uppercase tracking-wider">System Reminder</span>
            </div>
            <span className="text-[9px] opacity-40 font-bold">Today</span>
          </div>
          <p className="text-xs text-[#3E3E3E]/70">
            {user.language === 'English' ? 'Remember to check your hydration level and vitamin intake!' : 'Kumbuka kukagua kiwango chako cha maji na matumizi ya vitamini!'}
          </p>
        </div>

        {/* Empty State if needed */}
        {!appContent?.globalNotification && (
           <div className="flex flex-col items-center justify-center py-20 opacity-20">
             <Info size={48} className="mb-2" />
             <p className="font-bold">{t('no_notifications')}</p>
           </div>
        )}
      </div>
    </div>
  );
};

export default Notifications;
