
import React, { useState, useMemo } from 'react';
import { UserProfile, Screen, AppContent } from '../types';
import { 
  Calendar, 
  Utensils, 
  Heart, 
  Speaker, 
  Phone, 
  X, 
  Save, 
  Timer, 
  Edit3, 
  Upload, 
  MessageCircle, 
  Database,
  AlertCircle
} from 'lucide-react';

interface DashboardProps {
  user: UserProfile;
  navigate: (screen: Screen) => void;
  t: (key: string) => string;
}

const Dashboard: React.FC<DashboardProps> = ({ user, navigate, t }) => {
  const [showEmergency, setShowEmergency] = useState(false);
  const [showInsightEdit, setShowInsightEdit] = useState(false);
  
  const [appContent, setAppContent] = useState<AppContent>(() => {
    const saved = localStorage.getItem('ingia_app_content');
    return saved ? JSON.parse(saved) : null;
  });

  const [tempInsight, setTempInsight] = useState({ 
    English: appContent?.dailyInsight?.English || "", 
    Swahili: appContent?.dailyInsight?.Swahili || "",
    image: appContent?.dailyInsight?.image
  });

  const expertPhone = "+255745922477";
  const PREGNANCY_TOTAL_DAYS = 280;

  const pregnancyStats = useMemo(() => {
    const regDate = new Date(user.registrationDate || new Date().toISOString());
    const today = new Date();
    const diffMs = today.getTime() - regDate.getTime();
    const daysSinceReg = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    let initialDays = 0;
    const entryVal = user.pregnancyEntryValue || 0;
    if (user.pregnancyEntryUnit === 'DAYS') initialDays = entryVal;
    else if (user.pregnancyEntryUnit === 'WEEKS') initialDays = entryVal * 7;
    else if (user.pregnancyEntryUnit === 'MONTHS') initialDays = entryVal * 30;
    const currentTotalDays = Math.min(PREGNANCY_TOTAL_DAYS, initialDays + daysSinceReg);
    const progressPercent = (currentTotalDays / PREGNANCY_TOTAL_DAYS) * 100;

    return {
      currentWeeks: Math.floor(currentTotalDays / 7),
      currentRemainingDays: currentTotalDays % 7,
      progressPercent,
      trimester: Math.floor(currentTotalDays / 7) <= 12 ? 1 : Math.floor(currentTotalDays / 7) <= 27 ? 2 : 3,
      remMonths: Math.floor((PREGNANCY_TOTAL_DAYS - currentTotalDays) / 30),
      remWeeks: Math.floor(((PREGNANCY_TOTAL_DAYS - currentTotalDays) % 30) / 7),
      remDays: (PREGNANCY_TOTAL_DAYS - currentTotalDays) % 7
    };
  }, [user]);

  const handleSaveInsight = () => {
    const updated = { ...appContent, dailyInsight: { ...tempInsight } };
    setAppContent(updated as AppContent);
    localStorage.setItem('ingia_app_content', JSON.stringify(updated));
    setShowInsightEdit(false);
  };

  const dailyTip = user.language === 'English' ? (appContent?.dailyInsight?.English || "") : (appContent?.dailyInsight?.Swahili || "");

  return (
    <div className="space-y-6 animate-fadeIn pb-4">
      {/* Medical Disclaimer - Mandatory for Play Store health apps */}
      <div className="bg-amber-50 border border-amber-200 p-3 rounded-2xl flex items-start gap-2">
        <AlertCircle size={16} className="text-amber-500 flex-shrink-0 mt-0.5" />
        <p className="text-[10px] text-amber-800 leading-tight">
          {t('medical_disclaimer')}
        </p>
      </div>

      <div className="flex justify-between items-center px-2">
        <div>
          <h2 className="text-2xl font-bold text-[#3E3E3E] leading-tight">{t('welcome')}</h2>
          <p className="text-xs text-[#3E3E3E]/70 italic">{user.language === 'English' ? appContent?.welcomeMessage?.English : appContent?.welcomeMessage?.Swahili}</p>
        </div>
      </div>

      <section className="bg-[#E3F6E3] rounded-[2.5rem] p-6 border border-white/50 relative overflow-hidden shadow-sm">
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Timer size={16} className="text-[#A8C3B1]" />
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#A8C3B1]">{t('age_now')}</span>
              </div>
              <h2 className="text-2xl font-bold text-[#3E3E3E]">
                {pregnancyStats.currentWeeks} {t('weeks')}, {pregnancyStats.currentRemainingDays} {t('days')}
              </h2>
            </div>
            <div className="bg-[#F3C6CF] px-3 py-1 rounded-full text-[10px] font-bold text-white uppercase tracking-wider">
              {t('trimester')} {pregnancyStats.trimester}
            </div>
          </div>
          <div className="w-full bg-white/50 rounded-full h-3 mb-6">
            <div className="bg-[#A8C3B1] h-full rounded-full transition-all duration-1000" style={{ width: `${pregnancyStats.progressPercent}%` }} />
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-white/40 p-3 rounded-2xl text-center">
              <p className="text-[18px] font-bold text-[#3E3E3E]">{pregnancyStats.remMonths}</p>
              <p className="text-[9px] font-bold uppercase text-[#A8C3B1]">{t('months')}</p>
            </div>
            <div className="bg-white/40 p-3 rounded-2xl text-center">
              <p className="text-[18px] font-bold text-[#3E3E3E]">{pregnancyStats.remWeeks}</p>
              <p className="text-[9px] font-bold uppercase text-[#A8C3B1]">{t('weeks')}</p>
            </div>
            <div className="bg-white/40 p-3 rounded-2xl text-center">
              <p className="text-[18px] font-bold text-[#3E3E3E]">{pregnancyStats.remDays}</p>
              <p className="text-[9px] font-bold uppercase text-[#A8C3B1]">{t('days')}</p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white rounded-[2rem] p-5 shadow-sm border border-[#A8C3B1]/20">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-[#A8C3B1]">{t('insight')}</h3>
          <div className="flex gap-2">
            {user.role === 'INSTRUCTOR' && (
              <button onClick={() => setShowInsightEdit(true)} className="w-8 h-8 rounded-full bg-[#F3C6CF]/20 flex items-center justify-center text-[#F7B7A3]"><Edit3 size={16} /></button>
            )}
            <button onClick={() => window.speechSynthesis.speak(new SpeechSynthesisUtterance(dailyTip))} className="w-8 h-8 rounded-full bg-[#E3F6E3] flex items-center justify-center text-[#3E3E3E]"><Speaker size={16} /></button>
          </div>
        </div>
        <div className="flex flex-col gap-4">
          {appContent?.dailyInsight?.image && <img src={appContent.dailyInsight.image} className="w-full h-40 object-cover rounded-2xl shadow-sm" alt="Tip" />}
          <p className="text-sm leading-relaxed text-[#3E3E3E]">{dailyTip}</p>
        </div>
      </section>

      <div className="grid grid-cols-2 gap-3">
        {[
          { label: t('tracker'), icon: Calendar, screen: Screen.TRACKING },
          { label: t('meals'), icon: Utensils, screen: Screen.MEAL_PLAN },
          { label: t('self_care'), icon: Heart, screen: Screen.MENTAL_HEALTH },
          { label: t('experts'), icon: MessageCircle, screen: Screen.CONSULTATION },
        ].map(({ label, icon: Icon, screen }) => (
          <button key={label} onClick={() => navigate(screen)} className="flex items-center gap-3 p-4 bg-white rounded-3xl shadow-sm border border-gray-50 active:scale-95 transition-all text-left">
            <div className="w-10 h-10 bg-[#E3F6E3] rounded-2xl flex items-center justify-center text-[#A8C3B1]"><Icon size={20} /></div>
            <span className="text-xs font-bold text-[#3E3E3E]">{label}</span>
          </button>
        ))}
      </div>

      <button onClick={() => setShowEmergency(true)} className="w-full bg-[#F7B7A3] text-white p-5 rounded-[2.5rem] font-bold shadow-lg flex items-center justify-center gap-3">
        <Phone size={24} /> {t('emergency_btn')}
      </button>

      {showEmergency && (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-6 animate-fadeIn">
          <div className="bg-white w-full max-w-sm rounded-[3rem] p-8 shadow-2xl space-y-6">
            <div className="flex justify-center"><div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center text-red-500"><Phone size={32} /></div></div>
            <div className="text-center"><h3 className="text-xl font-bold text-[#3E3E3E]">{t('emergency_btn')}</h3><p className="text-sm opacity-60 mt-2">{t('emergency_desc')}</p></div>
            <a href={`tel:${expertPhone}`} className="w-full bg-[#F7B7A3] text-white p-5 rounded-3xl font-bold flex items-center justify-center gap-3 shadow-lg"><Phone size={20} /> {t('call_now')}</a>
            <button onClick={() => setShowEmergency(false)} className="w-full text-[#3E3E3E]/40 text-xs font-bold uppercase tracking-widest">{t('back')}</button>
          </div>
        </div>
      )}

      {showInsightEdit && (
        <div className="fixed inset-0 z-[110] bg-black/60 backdrop-blur-sm flex items-end animate-fadeIn">
          <div className="bg-white w-full rounded-t-[3rem] p-8 space-y-4 animate-slideInUp">
            <div className="flex justify-between items-center"><h3 className="text-xl font-bold">{t('edit_insight')}</h3><button onClick={() => setShowInsightEdit(false)}><X /></button></div>
            <textarea className="w-full p-4 bg-gray-50 rounded-2xl h-24 outline-none" placeholder="English Insight" value={tempInsight.English} onChange={e => setTempInsight({...tempInsight, English: e.target.value})} />
            <textarea className="w-full p-4 bg-gray-50 rounded-2xl h-24 outline-none" placeholder="Swahili Insight" value={tempInsight.Swahili} onChange={e => setTempInsight({...tempInsight, Swahili: e.target.value})} />
            <button onClick={handleSaveInsight} className="w-full bg-[#A8C3B1] text-white p-4 rounded-3xl font-bold flex items-center justify-center gap-2"><Save size={18} /> {t('complete')}</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
