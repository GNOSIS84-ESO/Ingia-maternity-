
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { UserProfile, ChatMessage, UserRole } from '../types';
import { Send, Phone, User, MessageSquare, ChevronLeft, Sparkles, Loader2, Mic } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { requestMicrophonePermission } from '../utils/permissions';

interface ConsultationProps {
  user: UserProfile;
  t: (key: string) => string;
}

const Consultation: React.FC<ConsultationProps> = ({ user, t }) => {
  const [globalMessages, setGlobalMessages] = useState<Record<string, ChatMessage[]>>(() => {
    const saved = localStorage.getItem('ingia_global_messages');
    return saved ? JSON.parse(saved) : {};
  });

  const [selectedRecipientId, setSelectedRecipientId] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [isAiMode, setIsAiMode] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const phoneNumber = "+255745922477";

  const scrollToBottom = useCallback(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [selectedRecipientId, globalMessages, isAiLoading, scrollToBottom]);

  const saveMessages = (msgs: Record<string, ChatMessage[]>) => {
    setGlobalMessages(msgs);
    localStorage.setItem('ingia_global_messages', JSON.stringify(msgs));
  };

  const handleVoiceRecord = async () => {
    if (isRecording) {
      setIsRecording(false);
      return;
    }
    const granted = await requestMicrophonePermission();
    if (granted) {
      setIsRecording(true);
      setTimeout(() => {
        setIsRecording(false);
        setInput(user.language === 'English' ? "Voice Message Recorded" : "Ujumbe wa sauti umerekodiwa");
      }, 2000);
    } else {
      alert("Microphone access is required for voice messages.");
    }
  };

  const handleAiConsultation = async (userQuery: string, targetId: string) => {
    setIsAiLoading(true);
    try {
      // Security: Initialize fresh instance for every call as per guidelines
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userQuery,
        config: {
          systemInstruction: `You are Leonia AI, a professional Midwife Assistant for Ingia Maternity.
          Provide fast, empathetic, and accurate advice for expectant mothers.
          Language: ${user.language}. Style: Warm, clinical yet accessible.
          Emergency Protocol: If the query suggests severe pain, heavy bleeding, or decreased movement, start with: "MAMA, CALL EMERGENCY NOW +255745922477".`,
          temperature: 0.7,
          topP: 0.9,
          maxOutputTokens: 500
        }
      });

      const aiText = response.text || (user.language === 'English' ? "I couldn't process that. Please try again." : "Samahani, jaribu tena.");
      
      const aiMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        text: aiText,
        senderId: 'ai-assistant',
        senderRole: 'INSTRUCTOR',
        senderName: 'Leonia AI',
        timestamp: new Date().toISOString()
      };

      setGlobalMessages(prev => {
        const updated = {
          ...prev,
          [targetId]: [...(prev[targetId] || []), aiMessage]
        };
        localStorage.setItem('ingia_global_messages', JSON.stringify(updated));
        return updated;
      });
    } catch (error) {
      console.error("AI Error:", error);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleSend = async () => {
    const trimmedInput = input.trim();
    if (!trimmedInput) return;
    
    const targetId = user.role === 'RECIPIENT' ? user.id : selectedRecipientId;
    if (!targetId) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: trimmedInput,
      senderId: user.id,
      senderRole: user.role,
      senderName: user.name,
      timestamp: new Date().toISOString()
    };

    const currentMsgs = globalMessages[targetId] || [];
    const updatedGlobal = {
      ...globalMessages,
      [targetId]: [...currentMsgs, userMessage]
    };

    saveMessages(updatedGlobal);
    setInput("");

    if (isAiMode && user.role === 'RECIPIENT') {
      await handleAiConsultation(trimmedInput, targetId);
    }
  };

  const formatTime = (iso: string) => {
    return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (user.role === 'INSTRUCTOR' && !selectedRecipientId) {
    const activeChats = JSON.parse(localStorage.getItem('ingia_database') || '[]')
      .filter((r: UserProfile) => globalMessages[r.id]?.length > 0);

    return (
      <div className="flex flex-col h-full animate-fadeIn space-y-6">
        <h2 className="text-2xl font-bold">{t('active_chats')}</h2>
        <div className="flex-1 overflow-y-auto space-y-3">
          {activeChats.map((r: UserProfile) => {
            const msgs = globalMessages[r.id];
            const lastMsg = msgs[msgs.length - 1];
            return (
              <button
                key={r.id}
                onClick={() => setSelectedRecipientId(r.id)}
                className="w-full bg-white p-5 rounded-[2rem] shadow-sm flex items-center gap-4 border border-transparent hover:border-[#A8C3B1] active:scale-[0.98] transition-all"
              >
                <div className="w-12 h-12 bg-[#F3C6CF] rounded-2xl flex items-center justify-center text-white font-bold text-lg">
                  {r.name[0]}
                </div>
                <div className="flex-1 text-left">
                  <h4 className="font-bold text-sm">{r.name}</h4>
                  <p className="text-[10px] text-gray-400 truncate max-w-[180px]">
                    {lastMsg.senderRole === 'INSTRUCTOR' ? 'Staff: ' : ''}{lastMsg.text}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-[9px] font-bold text-[#A8C3B1]">{formatTime(lastMsg.timestamp)}</p>
                </div>
              </button>
            );
          })}
          {activeChats.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20 opacity-20">
              <MessageSquare size={64} className="mb-4" />
              <p className="font-bold">{t('no_chats')}</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  const chatUserId = user.role === 'RECIPIENT' ? user.id : selectedRecipientId!;
  const chatMessages = globalMessages[chatUserId] || [];

  return (
    <div className="flex flex-col h-[calc(100vh-160px)] animate-fadeIn">
      <div className="bg-[#E3F6E3] p-4 rounded-[2rem] mb-4 border border-white flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          {user.role === 'INSTRUCTOR' && (
            <button onClick={() => setSelectedRecipientId(null)} className="p-2 bg-white rounded-full text-[#A8C3B1] mr-1">
              <ChevronLeft size={20} />
            </button>
          )}
          <div className={`w-12 h-12 rounded-full border-2 border-white flex items-center justify-center overflow-hidden ${isAiMode ? 'bg-[#F7B7A3]' : 'bg-[#A8C3B1]'}`}>
            {isAiMode ? <Sparkles className="text-white" size={24} /> : <User className="text-white" size={28} />}
          </div>
          <div>
            <h3 className="text-[11px] font-bold uppercase tracking-tight opacity-40">{isAiMode ? 'AI Assistant' : t('expert_role')}</h3>
            <h2 className="text-sm font-bold text-[#3E3E3E]">{isAiMode ? 'Leonia AI' : 'Midwife LEONIA'}</h2>
          </div>
        </div>
        
        {user.role === 'RECIPIENT' && (
          <div className="flex gap-2">
            <button 
              onClick={() => setIsAiMode(!isAiMode)}
              className={`p-3 rounded-full shadow-sm active:scale-90 transition-all ${isAiMode ? 'bg-[#F7B7A3] text-white' : 'bg-white text-[#F7B7A3]'}`}
            >
              <Sparkles size={20} />
            </button>
            <button 
              onClick={() => window.location.href = `tel:${phoneNumber}`}
              className="p-3 bg-white rounded-full text-[#A8C3B1] shadow-sm active:scale-90 transition-transform"
            >
              <Phone size={20} />
            </button>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto space-y-4 px-1 pb-4 scroll-smooth">
        {chatMessages.map((m: ChatMessage, i: number) => {
          const isMine = m.senderId === user.id;
          const isAi = m.senderId === 'ai-assistant';
          return (
            <div key={i} className={`flex ${isMine ? 'justify-end' : 'justify-start'} animate-fadeIn`}>
              <div className={`max-w-[85%] p-4 rounded-[2.5rem] shadow-sm text-sm ${
                isMine 
                  ? 'bg-[#F7B7A3] text-white rounded-tr-none' 
                  : isAi 
                    ? 'bg-white border-2 border-[#F7B7A3]/30 text-[#3E3E3E] rounded-tl-none'
                    : 'bg-white text-[#3E3E3E] rounded-tl-none border border-gray-100'
              }`}>
                {isAi && <div className="flex items-center gap-1 mb-1 text-[#F7B7A3] font-bold text-[9px] uppercase tracking-widest"><Sparkles size={10} /> AI Advice</div>}
                {m.text}
                <p className={`text-[9px] mt-1 opacity-60 ${isMine ? 'text-white' : ''}`}>{formatTime(m.timestamp)}</p>
              </div>
            </div>
          );
        })}
        {isAiLoading && (
          <div className="flex justify-start animate-pulse">
             <div className="bg-white border-2 border-dashed border-[#F7B7A3]/30 p-4 rounded-[2.5rem] rounded-tl-none flex items-center gap-2">
               <Loader2 size={16} className="text-[#F7B7A3] animate-spin" />
               <span className="text-[10px] font-bold text-[#F7B7A3] uppercase tracking-wider">Leonia AI Thinking...</span>
             </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      <div className="bg-white p-2 rounded-[2.5rem] flex items-center gap-2 shadow-md border border-gray-100">
        <button 
          onClick={handleVoiceRecord}
          className={`p-3 rounded-full transition-all ${isRecording ? 'bg-red-500 text-white animate-pulse' : 'text-[#A8C3B1]'}`}
        >
          <Mic size={20} />
        </button>
        <input 
          type="text" 
          placeholder={isAiMode ? "Ask AI Assistant..." : "Type to Midwife..."}
          className="flex-1 bg-transparent border-none outline-none text-sm py-3 px-4"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyPress={e => e.key === 'Enter' && handleSend()}
        />
        <button 
          onClick={handleSend}
          className={`w-12 h-12 rounded-full flex items-center justify-center text-white shadow-sm transition-all ${
            input.trim() ? (isAiMode ? 'bg-[#F7B7A3]' : 'bg-[#A8C3B1]') + ' active:scale-95' : 'bg-gray-200'
          }`}
          disabled={!input.trim() || isAiLoading}
        >
          <Send size={20} />
        </button>
      </div>
    </div>
  );
};

export default Consultation;
