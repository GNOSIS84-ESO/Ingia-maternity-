
import React, { useState } from 'react';
import { UserProfile, LiteracyMode, Language, translations, PregnancyUnit } from '../types';
import { ChevronRight, ChevronLeft, Heart, Mic, Image as ImageIcon, Type as TextIcon, Languages, Activity, Loader2, Calendar as CalendarIcon, MapPin } from 'lucide-react';
import { requestLocationPermission } from '../utils/permissions';

interface RegistrationProps {
  onComplete: (profile: UserProfile) => Promise<void>;
  onCancel?: () => void;
}

const Registration: React.FC<RegistrationProps> = ({ onComplete, onCancel }) => {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLocating, setIsLocating] = useState(false);
  const [formData, setFormData] = useState<Partial<UserProfile>>({
    id: Math.random().toString(36).substr(2, 9),
    role: 'RECIPIENT',
    language: 'English',
    literacyMode: 'TEXT',
    pregnancyEntryValue: 4,
    pregnancyEntryUnit: 'WEEKS',
    registrationDate: new Date().toISOString(),
    pregnanciesCount: 0,
    liveBirths: 0,
    livingChildren: 0,
    abortionsMiscarriages: 0,
    bloodGroup: '',
    lnmp: '',
    chronicDiseases: [],
    password: '',
  });

  const updateField = (field: keyof UserProfile, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleGetLocation = async () => {
    setIsLocating(true);
    const pos = await requestLocationPermission();
    if (pos) {
      // In a real app, we'd reverse geocode here. 
      // For now, we'll store coordinates as a string placeholder.
      updateField('location', `Lat: ${pos.coords.latitude.toFixed(2)}, Lon: ${pos.coords.longitude.toFixed(2)}`);
    } else {
      alert("Please allow location access in your browser settings.");
    }
    setIsLocating(false);
  };

  const toggleChronicDisease = (disease: string) => {
    const current = formData.chronicDiseases || [];
    if (current.includes(disease)) {
      updateField('chronicDiseases', current.filter(d => d !== disease));
    } else {
      updateField('chronicDiseases', [...current, disease]);
    }
  };

  const handleNext = () => setStep(s => s + 1);
  const handleBack = () => {
    if (step === 1) {
      onCancel?.();
    } else {
      setStep(s => s - 1);
    }
  };

  const t = (key: string) => {
    const lang = formData.language || 'English';
    return translations[lang][key] || key;
  };

  const isFormValid = () => {
    if (step === 1) return formData.name && formData.phone && formData.password?.length === 4;
    if (step === 2) return formData.pregnancyEntryValue && formData.pregnancyEntryUnit && formData.lnmp;
    if (step === 3) return formData.bloodGroup;
    if (step === 4) return formData.emergencyContact;
    return true;
  };

  const handleComplete = async () => {
    setIsSubmitting(true);
    let calculatedWeeks = 0;
    const val = formData.pregnancyEntryValue || 0;
    if (formData.pregnancyEntryUnit === 'DAYS') calculatedWeeks = Math.floor(val / 7);
    if (formData.pregnancyEntryUnit === 'WEEKS') calculatedWeeks = val;
    if (formData.pregnancyEntryUnit === 'MONTHS') calculatedWeeks = val * 4;
    
    const finalProfile = { 
      ...formData, 
      weeksPregnant: calculatedWeeks,
      registrationDate: new Date().toISOString()
    } as UserProfile;

    await onComplete(finalProfile);
    setIsSubmitting(false);
  };

  const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
  const diseaseOptions = [
    { id: 'HIV', label: 'HIV' },
    { id: 'BP', label: formData.language === 'English' ? 'Blood Pressure' : 'Shinikizo la Damu' },
    { id: 'TB', label: 'TB' },
    { id: 'Asthma', label: formData.language === 'English' ? 'Asthma' : 'Pumu' },
    { id: 'Diabetes', label: formData.language === 'English' ? 'Diabetes' : 'Sukari' }
  ];

  if (isSubmitting) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4 animate-fadeIn">
        <Loader2 size={48} className="text-[#F7B7A3] animate-spin" />
        <p className="font-bold text-[#3E3E3E]">{t('notifying')}</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full animate-fadeIn">
      <div className="text-center mb-8">
        <div className="inline-block p-4 bg-white rounded-3xl shadow-sm mb-4">
          <div className="w-16 h-16 bg-[#F3C6CF] rounded-full flex items-center justify-center border-4 border-white">
             <Heart className="text-white fill-white" size={32} />
          </div>
        </div>
        <h2 className="text-2xl font-bold text-[#3E3E3E]">{t('welcome')}</h2>
        <p className="text-sm text-[#3E3E3E]/70 italic">{t('welcome_sub')}</p>
      </div>

      <div className="bg-[#E3F6E3] p-6 rounded-[2.5rem] shadow-sm flex-1 mb-6 border border-white/50 overflow-y-auto">
        <div className="mb-6 flex justify-between items-center sticky top-0 bg-[#E3F6E3] z-10 py-1">
          <span className="text-xs font-bold text-[#A8C3B1] uppercase tracking-widest">
            {t('step')} {step} {t('of')} 4
          </span>
          <div className="flex gap-1">
            {[1, 2, 3, 4].map(s => (
              <div key={s} className={`h-1.5 w-6 rounded-full transition-all ${s <= step ? 'bg-[#A8C3B1]' : 'bg-white'}`} />
            ))}
          </div>
        </div>

        {step === 1 && (
          <div className="space-y-4 animate-slideInRight">
            <h3 className="text-lg font-semibold mb-2">{t('basic_info')}</h3>
            
            <div>
              <label className="block text-xs font-medium text-[#3E3E3E] mb-1">{t('language_selection')}</label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {(['English', 'Swahili'] as Language[]).map((lang) => (
                  <button
                    key={lang}
                    onClick={() => updateField('language', lang)}
                    className={`flex items-center justify-center gap-2 p-3 rounded-2xl border-2 transition-all ${
                      formData.language === lang ? 'border-[#F7B7A3] bg-[#F7B7A3]/5' : 'border-white bg-white/50'
                    }`}
                  >
                    <Languages size={18} className={formData.language === lang ? 'text-[#F7B7A3]' : 'text-[#3E3E3E]/40'} />
                    <span className="text-xs font-bold">{lang}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#3E3E3E] mb-1">{t('your_name')}</label>
              <input 
                type="text" 
                className="w-full bg-white border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-[#F7B7A3] outline-none"
                placeholder={t('name_placeholder')}
                value={formData.name || ''}
                onChange={e => updateField('name', e.target.value)}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-[#3E3E3E] mb-1">{t('phone_number')}</label>
                <input 
                  type="tel" 
                  className="w-full bg-white border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-[#F7B7A3] outline-none"
                  placeholder={t('phone_placeholder')}
                  value={formData.phone || ''}
                  onChange={e => updateField('phone', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#3E3E3E] mb-1">{t('password')}</label>
                <input 
                  type="password" 
                  maxLength={4}
                  className="w-full bg-white border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-[#F7B7A3] outline-none text-center font-bold tracking-widest"
                  placeholder="****"
                  value={formData.password || ''}
                  onChange={e => updateField('password', e.target.value)}
                />
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4 animate-slideInRight">
            <h3 className="text-lg font-semibold mb-2">{t('pregnancy_details')}</h3>
            
            <div className="bg-white p-4 rounded-3xl space-y-4">
              <label className="block text-xs font-bold text-[#A8C3B1] uppercase tracking-tighter">
                {t('pregnancy_age_label')}
              </label>
              
              <div className="flex items-center gap-2">
                <input 
                  type="number" 
                  min="0"
                  className="flex-1 bg-[#E3F6E3]/40 border-none rounded-2xl p-4 text-xl font-bold focus:ring-2 focus:ring-[#F7B7A3] outline-none text-center"
                  value={formData.pregnancyEntryValue || ''}
                  onChange={e => updateField('pregnancyEntryValue', parseInt(e.target.value) || 0)}
                  placeholder="0"
                />
                
                <div className="flex flex-col gap-1 flex-1">
                  {(['DAYS', 'WEEKS', 'MONTHS'] as PregnancyUnit[]).map((unit) => (
                    <button
                      key={unit}
                      onClick={() => updateField('pregnancyEntryUnit', unit)}
                      className={`p-2 rounded-xl text-[10px] font-bold transition-all border ${
                        formData.pregnancyEntryUnit === unit ? 'bg-[#F7B7A3] text-white border-transparent' : 'bg-white text-[#3E3E3E]/40 border-gray-100'
                      }`}
                    >
                      {t(unit.toLowerCase())}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#3E3E3E] mb-1">{t('lnmp')}</label>
              <div className="relative">
                <input 
                  type="date" 
                  className="w-full bg-white border-none rounded-2xl p-4 pl-12 text-sm focus:ring-2 focus:ring-[#F7B7A3] outline-none"
                  value={formData.lnmp || ''}
                  onChange={e => updateField('lnmp', e.target.value)}
                />
                <CalendarIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-[#A8C3B1]" size={18} />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="block text-xs font-medium text-[#3E3E3E] mb-1">{t('location_ward')}</label>
              <div className="flex gap-2">
                <input 
                  type="text" 
                  className="flex-1 bg-white border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-[#F7B7A3] outline-none"
                  placeholder="e.g. Kinondoni, Dar es Salaam"
                  value={formData.location || ''}
                  onChange={e => updateField('location', e.target.value)}
                />
                <button 
                  onClick={handleGetLocation}
                  disabled={isLocating}
                  className={`p-4 bg-white rounded-2xl shadow-sm text-[#A8C3B1] active:scale-95 transition-all ${isLocating ? 'animate-pulse' : ''}`}
                >
                  <MapPin size={20} />
                </button>
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4 animate-slideInRight">
            <h3 className="text-lg font-semibold mb-2">{t('history')}</h3>
            
            <div>
              <label className="block text-xs font-medium text-[#3E3E3E] mb-1">{t('blood_group')}</label>
              <div className="grid grid-cols-4 gap-2 mt-2">
                {bloodGroups.map((bg) => (
                  <button
                    key={bg}
                    onClick={() => updateField('bloodGroup', bg)}
                    className={`p-2 rounded-xl border-2 text-xs font-bold transition-all ${
                      formData.bloodGroup === bg ? 'border-[#F7B7A3] bg-[#F7B7A3]/5' : 'border-white bg-white/50'
                    }`}
                  >
                    {bg}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#3E3E3E] mb-1">{t('chronic_diseases')}</label>
              <p className="text-[10px] text-[#3E3E3E]/60 mb-2">{t('diseases_hint')}</p>
              <div className="flex flex-wrap gap-2 mt-1">
                {diseaseOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => toggleChronicDisease(opt.id)}
                    className={`px-3 py-2 rounded-xl border-2 text-[10px] font-bold transition-all flex items-center gap-1 ${
                      formData.chronicDiseases?.includes(opt.id) ? 'border-[#A8C3B1] bg-[#A8C3B1]/10' : 'border-white bg-white/50'
                    }`}
                  >
                    <Activity size={12} />
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3 pt-2">
              {[
                { label: formData.language === 'English' ? 'Total Pregnancies' : 'Jumla ya Mimba', field: 'pregnanciesCount' },
                { label: formData.language === 'English' ? 'Total Live Births' : 'Jumla ya Vizazi Hai', field: 'liveBirths' },
                { label: formData.language === 'English' ? 'Living Children' : 'Watoto Walio Hai', field: 'livingChildren' },
                { label: formData.language === 'English' ? 'Abortions / Miscarriages' : 'Uharibifu wa Mimba', field: 'abortionsMiscarriages' }
              ].map(item => (
                <div key={item.field} className="flex justify-between items-center bg-white p-3 rounded-2xl">
                  <span className="text-[11px] font-medium">{item.label}</span>
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={() => updateField(item.field as any, Math.max(0, (formData[item.field as keyof UserProfile] as number) - 1))}
                      className="w-7 h-7 rounded-full bg-[#B7E4C7] flex items-center justify-center font-bold text-xs"
                    >-</button>
                    <span className="w-4 text-center font-bold text-xs">{(formData as any)[item.field]}</span>
                    <button 
                      onClick={() => updateField(item.field as any, (formData[item.field as keyof UserProfile] as number) + 1)}
                      className="w-7 h-7 rounded-full bg-[#B7E4C7] flex items-center justify-center font-bold text-xs"
                    >+</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-4 animate-slideInRight">
            <h3 className="text-lg font-semibold mb-2">{t('safety_consent')}</h3>
            <div>
              <label className="block text-xs font-medium text-[#3E3E3E] mb-1">{t('emergency_contact')}</label>
              <input 
                type="tel" 
                className="w-full bg-white border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-[#F7B7A3] outline-none"
                placeholder={t('emergency_placeholder')}
                value={formData.emergencyContact || ''}
                onChange={e => updateField('emergencyContact', e.target.value)}
              />
            </div>
            <div className="bg-white/50 p-4 rounded-2xl text-[11px] leading-relaxed">
              <p className="font-bold mb-1">{t('privacy_agreement')}</p>
              {t('privacy_text')}
            </div>
          </div>
        )}
      </div>

      <div className="flex gap-4 p-1">
        <button 
          onClick={handleBack}
          className="flex-1 bg-white p-4 rounded-[2rem] text-[#3E3E3E] font-bold shadow-sm transition-transform active:scale-95 flex items-center justify-center gap-2"
        >
          <ChevronLeft size={20} /> {t('back')}
        </button>
        <button 
          onClick={step === 4 ? handleComplete : handleNext}
          disabled={!isFormValid() || isSubmitting}
          className={`flex-[2] p-4 rounded-[2rem] font-bold text-white shadow-md transition-all active:scale-95 flex items-center justify-center gap-2 ${
            isFormValid() ? 'bg-[#F7B7A3]' : 'bg-gray-300 cursor-not-allowed'
          }`}
        >
          {isSubmitting ? <Loader2 className="animate-spin" /> : step === 4 ? t('complete') : t('next')}
          {!isSubmitting && <ChevronRight size={20} />}
        </button>
      </div>
    </div>
  );
};

export default Registration;
