
import React, { useState, useRef } from 'react';
import { UserProfile, AppContent, AboutContent } from '../types';
import { ChevronLeft, Info, FileText, Save, Plus, Trash2, X, ExternalLink, Edit3, Upload, Loader2, ShieldCheck, Cloud } from 'lucide-react';

interface AboutProps {
  user: UserProfile;
  t: (key: string) => string;
  onBack: () => void;
}

const About: React.FC<AboutProps> = ({ user, t, onBack }) => {
  const [appContent, setAppContent] = useState<AppContent>(() => {
    const saved = localStorage.getItem('ingia_app_content');
    return saved ? JSON.parse(saved) : null;
  });

  const [isEditing, setIsEditing] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [editAbout, setEditAbout] = useState<AboutContent>(appContent?.about || { description: '', attachments: [] });
  const [newAttachment, setNewAttachment] = useState({ name: '', url: '' });
  const [showAddFile, setShowAddFile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const hasApiKey = !!process.env.API_KEY;

  const handleSave = () => {
    const updated = { ...appContent, about: editAbout };
    setAppContent(updated as AppContent);
    localStorage.setItem('ingia_app_content', JSON.stringify(updated));
    setIsEditing(false);
    alert("About information updated successfully!");
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.type !== 'application/pdf') {
      alert("Please upload a PDF file.");
      return;
    }
    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      setNewAttachment({
        ...newAttachment,
        url: event.target?.result as string,
        name: newAttachment.name || file.name.replace('.pdf', '')
      });
      setIsUploading(false);
    };
    reader.readAsDataURL(file);
  };

  const addAttachment = () => {
    if (!newAttachment.name || !newAttachment.url) {
      alert("Please provide a name and select a PDF file.");
      return;
    }
    setEditAbout({
      ...editAbout,
      attachments: [...editAbout.attachments, { ...newAttachment }]
    });
    setNewAttachment({ name: '', url: '' });
    setShowAddFile(false);
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 bg-white rounded-full shadow-sm text-[#3E3E3E] active:scale-90 transition-transform">
            <ChevronLeft size={20} />
          </button>
          <h2 className="text-2xl font-bold">{t('about_app')}</h2>
        </div>
        {user.role === 'INSTRUCTOR' && (
          <button onClick={() => setIsEditing(!isEditing)} className="p-3 bg-[#A8C3B1] text-white rounded-2xl flex items-center gap-2 text-xs font-bold shadow-sm">
            {isEditing ? <X size={16} /> : <Edit3 size={16} />}
            {isEditing ? 'Cancel' : 'Edit Info'}
          </button>
        )}
      </div>

      <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-[#A8C3B1]/20 space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-[#E3F6E3] rounded-2xl flex items-center justify-center text-[#A8C3B1]">
            <Info size={24} />
          </div>
          <h3 className="font-bold text-[#3E3E3E] uppercase tracking-wider text-xs">{t('app_description')}</h3>
        </div>
        {isEditing ? (
          <textarea className="w-full bg-[#E3F6E3]/30 border-none rounded-2xl p-4 text-sm h-48 outline-none focus:ring-2 focus:ring-[#F7B7A3] resize-none" value={editAbout.description} onChange={(e) => setEditAbout({ ...editAbout, description: e.target.value })} />
        ) : (
          <p className="text-sm text-[#3E3E3E]/70 leading-relaxed italic">{appContent?.about.description}</p>
        )}
      </div>

      <section className="bg-white p-5 rounded-[2.5rem] border border-gray-100 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <Cloud className={`text-[#A8C3B1] ${hasApiKey ? 'opacity-100' : 'opacity-20'}`} size={20} />
          <div>
            <p className="text-xs font-bold">Netlify Cloud Status</p>
            <p className="text-[10px] text-gray-400 font-bold uppercase">{hasApiKey ? 'Connected & Ready' : 'Environment Pending'}</p>
          </div>
        </div>
        <div className={`w-2 h-2 rounded-full ${hasApiKey ? 'bg-green-400' : 'bg-amber-400'}`}></div>
      </section>

      <section className="bg-[#E3F6E3] p-6 rounded-[2.5rem] border border-white shadow-sm space-y-3">
        <div className="flex items-center gap-3 text-[#A8C3B1]">
          <ShieldCheck size={20} />
          <h3 className="font-bold uppercase tracking-wider text-xs">Privacy & Data Safety</h3>
        </div>
        <p className="text-[11px] text-[#3E3E3E]/70 leading-relaxed">
          Your health data is encrypted and stored securely. We comply with Google Play's health data policies. You can request data deletion at any time.
        </p>
      </section>

      {isEditing && (
        <button onClick={handleSave} className="w-full bg-[#F7B7A3] text-white p-5 rounded-[2.5rem] font-bold shadow-lg flex items-center justify-center gap-3">
          <Save size={20} /> Save Changes
        </button>
      )}
    </div>
  );
};

export default About;
