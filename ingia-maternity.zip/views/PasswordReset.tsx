
import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Smartphone, Calendar, ChevronLeft, Save, AlertCircle, ShieldCheck } from 'lucide-react';

interface PasswordResetProps {
  onBack: () => void;
  onSuccess: () => void;
  t: (key: string) => string;
}

const PasswordReset: React.FC<PasswordResetProps> = ({ onBack, onSuccess, t }) => {
  const [step, setStep] = useState(1);
  const [phone, setPhone] = useState('');
  const [lnmp, setLnmp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [error, setError] = useState('');
  const [matchedUser, setMatchedUser] = useState<UserProfile | null>(null);

  const handleVerify = () => {
    setError('');
    const database = JSON.parse(localStorage.getItem('ingia_database') || '[]');
    const user = database.find((u: UserProfile) => u.phone === phone && u.lnmp === lnmp);

    if (user) {
      setMatchedUser(user);
      setStep(2);
    } else {
      setError(user ? 'Incorrect verification data.' : 'No account found with this phone & LNMP.');
    }
  };

  const handleReset = () => {
    if (newPassword.length !== 4) {
      setError('Password must be 4 digits.');
      return;
    }

    const database = JSON.parse(localStorage.getItem('ingia_database') || '[]');
    const updatedDatabase = database.map((u: UserProfile) => 
      u.id === matchedUser?.id ? { ...u, password: newPassword } : u
    );

    localStorage.setItem('ingia_database', JSON.stringify(updatedDatabase));
    alert('Password reset successful! Please log in.');
    onSuccess();
  };

  return (
    <div className="flex flex-col items-center justify-center h-full animate-fadeIn p-6">
      <button 
        onClick={onBack}
        className="absolute top-8 left-6 p-3 bg-white rounded-full shadow-sm text-[#3E3E3E] active:scale-90 transition-transform"
      >
        <ChevronLeft size={20} />
      </button>

      <div className="mb-10 flex flex-col items-center">
        <div className="w-16 h-16 bg-[#F3C6CF] rounded-[2rem] flex items-center justify-center text-white mb-4 shadow-sm">
          <ShieldCheck size={32} />
        </div>
        <h1 className="text-2xl font-bold text-[#3E3E3E]">{t('reset_password')}</h1>
      </div>

      <div className="bg-white p-8 rounded-[3rem] shadow-xl w-full border border-[#F3C6CF]/20 space-y-6">
        {step === 1 ? (
          <div className="space-y-4">
            <p className="text-[10px] text-center font-bold text-[#A8C3B1] uppercase tracking-wider mb-4">{t('verify_hint')}</p>
            
            <div>
              <label className="block text-[10px] uppercase font-bold text-[#A8C3B1] mb-2 ml-1">{t('phone_number')}</label>
              <div className="relative">
                <input 
                  type="tel" 
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-[#E3F6E3]/30 border-none rounded-2xl p-4 pl-12 text-sm outline-none"
                  placeholder="0712..."
                />
                <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 text-[#A8C3B1]" size={18} />
              </div>
            </div>

            <div>
              <label className="block text-[10px] uppercase font-bold text-[#A8C3B1] mb-2 ml-1">{t('lnmp')}</label>
              <div className="relative">
                <input 
                  type="date" 
                  value={lnmp}
                  onChange={(e) => setLnmp(e.target.value)}
                  className="w-full bg-[#E3F6E3]/30 border-none rounded-2xl p-4 pl-12 text-sm outline-none"
                />
                <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-[#A8C3B1]" size={18} />
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 text-red-500 text-xs font-bold bg-red-50 p-3 rounded-xl">
                <AlertCircle size={14} />
                {error}
              </div>
            )}

            <button 
              onClick={handleVerify}
              className="w-full bg-[#F7B7A3] text-white p-4 rounded-2xl font-bold shadow-md active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              Thibitisha / Verify
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <h3 className="text-center font-bold text-[#3E3E3E]">{t('new_password')}</h3>
            
            <div>
              <div className="relative">
                <input 
                  type="password" 
                  maxLength={4}
                  autoFocus
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full bg-[#E3F6E3]/30 border-none rounded-2xl p-4 text-3xl font-bold tracking-[1em] text-center outline-none focus:ring-2 focus:ring-[#F7B7A3]"
                  placeholder="****"
                />
              </div>
            </div>

            <button 
              onClick={handleReset}
              className="w-full bg-[#A8C3B1] text-white p-4 rounded-2xl font-bold shadow-md active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <Save size={20} /> Update Password
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default PasswordReset;
