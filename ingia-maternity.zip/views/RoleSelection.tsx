
import React, { useState, useEffect } from 'react';
import { User, ShieldCheck, Heart, Lock, ChevronLeft, AlertCircle, Clock } from 'lucide-react';
import Logo from '../components/Logo';

interface RoleSelectionProps {
  onRecipientChoice: () => void;
  onInstructorAuth: () => void;
  t: (key: string) => string;
}

const RoleSelection: React.FC<RoleSelectionProps> = ({ onRecipientChoice, onInstructorAuth, t }) => {
  const [showPinInput, setShowPinInput] = useState(false);
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [attempts, setAttempts] = useState(0);
  const [isLocked, setIsLocked] = useState(false);
  const [lockTime, setLockTime] = useState(0);

  const CORRECT_PIN = "777847";
  const MAX_ATTEMPTS = 3;
  const LOCKOUT_DURATION = 30; // seconds

  useEffect(() => {
    let timer: number;
    if (isLocked && lockTime > 0) {
      timer = window.setInterval(() => {
        setLockTime((prev) => prev - 1);
      }, 1000);
    } else if (lockTime === 0) {
      setIsLocked(false);
      setAttempts(0);
    }
    return () => clearInterval(timer);
  }, [isLocked, lockTime]);

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLocked) return;

    if (pin === CORRECT_PIN) {
      setAttempts(0);
      onInstructorAuth();
    } else {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      setPin('');
      
      if (newAttempts >= MAX_ATTEMPTS) {
        setIsLocked(true);
        setLockTime(LOCKOUT_DURATION);
        setError(`Security Lock: Try again in ${LOCKOUT_DURATION}s`);
      } else {
        setError(`${t('incorrect_pin')} (${MAX_ATTEMPTS - newAttempts} attempts left)`);
      }
      
      setTimeout(() => {
        if (!isLocked) setError('');
      }, 3000);
    }
  };

  if (showPinInput) {
    return (
      <div className="flex flex-col items-center justify-center h-full animate-fadeIn p-6">
        <div className="bg-white p-8 rounded-[3rem] shadow-xl w-full border border-[#F3C6CF]/20">
          <div className="flex justify-center mb-6">
            <div className={`w-16 h-16 rounded-full flex items-center justify-center text-white transition-colors ${isLocked ? 'bg-red-400' : 'bg-[#F3C6CF]'}`}>
              {isLocked ? <Clock size={32} /> : <Lock size={32} />}
            </div>
          </div>
          <h2 className="text-xl font-bold text-center mb-2 text-[#3E3E3E]">{t('enter_pin')}</h2>
          <p className="text-[10px] text-center text-gray-400 uppercase font-bold tracking-widest mb-6">Secure Access Required</p>
          
          <form onSubmit={handlePinSubmit} className="space-y-6">
            <div className="relative">
              <input 
                type="password"
                maxLength={6}
                value={pin}
                disabled={isLocked}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                className={`w-full text-center text-3xl font-bold tracking-[0.5em] p-4 bg-[#E3F6E3]/30 rounded-2xl border-2 outline-none transition-all ${
                  isLocked ? 'opacity-50 border-red-100' : 'focus:border-[#F7B7A3] border-transparent'
                }`}
                placeholder="••••••"
                autoFocus
              />
            </div>
            
            {error && (
              <div className={`flex items-center justify-center gap-2 p-3 rounded-xl text-xs font-bold animate-pulse ${isLocked ? 'bg-red-50 text-red-500' : 'text-red-400'}`}>
                <AlertCircle size={14} />
                {isLocked ? `Locked for ${lockTime}s` : error}
              </div>
            )}
            
            <button 
              type="submit"
              disabled={pin.length < 6 || isLocked}
              className={`w-full p-4 rounded-2xl font-bold shadow-md transition-all flex items-center justify-center gap-2 ${
                pin.length === 6 && !isLocked ? 'bg-[#F7B7A3] text-white active:scale-95' : 'bg-gray-100 text-gray-400 cursor-not-allowed'
              }`}
            >
              <ShieldCheck size={20} /> Verify Identity
            </button>
            
            <button 
              type="button"
              onClick={() => {
                setShowPinInput(false);
                setError('');
                setPin('');
              }}
              className="w-full text-[#3E3E3E]/40 text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-1"
            >
              <ChevronLeft size={14} /> {t('back')}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center h-full animate-fadeIn p-6">
      <div className="mb-12 flex flex-col items-center">
        <Logo size="md" className="mb-6" />
        <h1 className="text-3xl font-bold text-[#3E3E3E]">Ingia Maternity</h1>
        <p className="text-sm opacity-60 italic">With you, mama</p>
      </div>

      <div className="w-full space-y-4">
        <button 
          onClick={onRecipientChoice}
          className="w-full bg-white p-8 rounded-[2.5rem] shadow-sm flex flex-col items-center gap-4 transition-all hover:scale-[1.02] active:scale-[0.98] border-2 border-transparent hover:border-[#A8C3B1]"
        >
          <div className="w-16 h-16 bg-[#B7E4C7] rounded-full flex items-center justify-center text-white shadow-inner">
            <Heart size={32} fill="white" />
          </div>
          <div className="text-center">
            <span className="block text-xl font-bold text-[#3E3E3E]">{t('recipients')}</span>
            <span className="text-[10px] text-[#3E3E3E]/40 uppercase font-bold tracking-widest">Register as Mother</span>
          </div>
        </button>

        <button 
          onClick={() => setShowPinInput(true)}
          className="w-full bg-[#E3F6E3]/60 p-8 rounded-[2.5rem] shadow-sm flex flex-col items-center gap-4 transition-all hover:scale-[1.02] active:scale-[0.98] border-2 border-white"
        >
          <div className="w-16 h-16 bg-[#F3C6CF] rounded-full flex items-center justify-center text-white shadow-inner">
            <ShieldCheck size={32} />
          </div>
          <div className="text-center">
            <span className="block text-xl font-bold text-[#3E3E3E]">{t('instructor')}</span>
            <span className="text-[10px] text-[#3E3E3E]/40 uppercase font-bold tracking-widest">Medical Staff Access</span>
          </div>
        </button>
      </div>
    </div>
  );
};

export default RoleSelection;
