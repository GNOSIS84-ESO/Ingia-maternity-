
import React from 'react';
import { ChevronLeft, Shield, Lock, Eye, Trash2 } from 'lucide-react';

interface PrivacyPolicyProps {
  onBack: () => void;
  t: (k: string) => string;
}

const PrivacyPolicy: React.FC<PrivacyPolicyProps> = ({ onBack, t }) => {
  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      <div className="flex items-center gap-4">
        <button onClick={onBack} className="p-2 bg-white rounded-full shadow-sm text-[#3E3E3E]">
          <ChevronLeft size={20} />
        </button>
        <h2 className="text-2xl font-bold">Privacy Policy</h2>
      </div>

      <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-[#A8C3B1]/20 space-y-6 text-sm text-[#3E3E3E]/80 leading-relaxed">
        <section className="space-y-2">
          <div className="flex items-center gap-2 text-[#A8C3B1]">
            <Shield size={18} />
            <h3 className="font-bold uppercase text-xs">Data Collection</h3>
          </div>
          <p>Ingia Maternity collects pregnancy health data (LNMP, weight, symptoms) and contact information to provide personalized care and enable communication with medical staff.</p>
        </section>

        <section className="space-y-2">
          <div className="flex items-center gap-2 text-[#A8C3B1]">
            <Lock size={18} />
            <h3 className="font-bold uppercase text-xs">Security</h3>
          </div>
          <p>Your data is encrypted in transit and at rest. We do not share your personal health information with third-party advertisers.</p>
        </section>

        <section className="space-y-2">
          <div className="flex items-center gap-2 text-[#A8C3B1]">
            <Eye size={18} />
            <h3 className="font-bold uppercase text-xs">Permissions</h3>
          </div>
          <p>We request Microphone and Camera access solely for telemedicine consultations with our Midwives. Location data is used to find nearby clinical facilities.</p>
        </section>

        <section className="space-y-2">
          <div className="flex items-center gap-2 text-[#F7B7A3]">
            <Trash2 size={18} />
            <h3 className="font-bold uppercase text-xs">Data Deletion</h3>
          </div>
          <p>Users have the right to delete their data at any time. You can perform a full data wipe in the App Settings or request account closure via the support chat.</p>
        </section>
      </div>
      
      <p className="text-center text-[10px] opacity-40">Last Updated: May 2024</p>
    </div>
  );
};

export default PrivacyPolicy;
