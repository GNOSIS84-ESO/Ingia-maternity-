
import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { Plus, TrendingUp, Info, Save, Edit3, Heart, Activity } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const Tracking: React.FC<{ user: UserProfile }> = ({ user }) => {
  const [activeTab, setActiveTab] = useState<'SYMPTOMS' | 'VITALS'>('SYMPTOMS');
  const [medicalNotes, setMedicalNotes] = useState(() => localStorage.getItem('ingia_medical_notes') || '');
  const [isEditingNotes, setIsEditingNotes] = useState(false);
  
  const [symptoms, setSymptoms] = useState(() => {
    const saved = localStorage.getItem('ingia_symptoms');
    return saved ? JSON.parse(saved) : [
      { name: 'Nausea', level: 'None', icon: '🤢' },
      { name: 'Fatigue', level: 'None', icon: '😴' },
      { name: 'Headache', level: 'None', icon: '🤕' },
      { name: 'Swelling', level: 'None', icon: '🦶' }
    ];
  });

  const [weight, setWeight] = useState('65.0');
  const [bp, setBp] = useState('110/70');
  const [vitalsHistory, setVitalsHistory] = useState(() => {
    const saved = localStorage.getItem('ingia_vitals_history');
    return saved ? JSON.parse(saved) : [
      { week: 4, weight: 65 },
      { week: 8, weight: 65.5 },
      { week: 12, weight: 67 },
      { week: 16, weight: 69 },
    ];
  });

  const levels = ['None', 'Mild', 'Moderate', 'Severe'];

  const updateSymptom = (index: number) => {
    const currentLevel = symptoms[index].level;
    const nextLevelIdx = (levels.indexOf(currentLevel) + 1) % levels.length;
    const newSymptoms = [...symptoms];
    newSymptoms[index].level = levels[nextLevelIdx];
    setSymptoms(newSymptoms);
    localStorage.setItem('ingia_symptoms', JSON.stringify(newSymptoms));
  };

  const saveVitals = () => {
    const newEntry = { week: user.weeksPregnant, weight: parseFloat(weight) };
    const updatedHistory = [...vitalsHistory.filter((h: any) => h.week !== user.weeksPregnant), newEntry].sort((a,b) => a.week - b.week);
    setVitalsHistory(updatedHistory);
    localStorage.setItem('ingia_vitals_history', JSON.stringify(updatedHistory));
    alert('Vitals updated!');
  };

  const saveNotes = () => {
    localStorage.setItem('ingia_medical_notes', medicalNotes);
    setIsEditingNotes(false);
    alert('Medical notes saved!');
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Health Tracker</h2>
        {user.role === 'INSTRUCTOR' && (
          <button onClick={saveVitals} className="bg-[#A8C3B1] text-white p-2 rounded-2xl text-xs font-bold px-4">
            <Save size={16} className="inline mr-1" /> Save Vitals
          </button>
        )}
      </div>

      <div className="flex bg-white rounded-2xl p-1 shadow-sm">
        <button onClick={() => setActiveTab('SYMPTOMS')} className={`flex-1 py-3 rounded-xl text-xs font-bold ${activeTab === 'SYMPTOMS' ? 'bg-[#A8C3B1] text-white' : 'text-[#3E3E3E]/60'}`}>Symptoms</button>
        <button onClick={() => setActiveTab('VITALS')} className={`flex-1 py-3 rounded-xl text-xs font-bold ${activeTab === 'VITALS' ? 'bg-[#A8C3B1] text-white' : 'text-[#3E3E3E]/60'}`}>My Vitals</button>
      </div>

      {activeTab === 'SYMPTOMS' ? (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
             {symptoms.map((s: any, i: number) => (
               <button key={i} onClick={() => updateSymptom(i)} className={`p-4 rounded-[2rem] border transition-all flex flex-col items-center shadow-sm ${s.level === 'None' ? 'bg-white' : 'bg-[#F3C6CF]/10 border-[#F3C6CF]'}`}>
                 <span className="text-3xl mb-2">{s.icon}</span>
                 <span className="text-xs font-bold">{s.name}</span>
                 <span className="text-[10px] mt-1 font-bold">{s.level}</span>
               </button>
             ))}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
             <div className="bg-white p-4 rounded-[2rem] shadow-sm border border-gray-50">
                <label className="text-[10px] font-bold uppercase text-gray-400">Weight (kg)</label>
                <input type="number" step="0.1" className="w-full text-xl font-bold bg-transparent text-center outline-none" value={weight} onChange={e => setWeight(e.target.value)} />
             </div>
             <div className="bg-white p-4 rounded-[2rem] shadow-sm border border-gray-50">
                <label className="text-[10px] font-bold uppercase text-gray-400">BP</label>
                <input type="text" className="w-full text-xl font-bold bg-transparent text-center outline-none" value={bp} onChange={e => setBp(e.target.value)} />
             </div>
          </div>
          
          <section className="bg-white p-6 rounded-[2.5rem] shadow-sm border">
            <h3 className="text-sm font-bold flex items-center gap-2 mb-4"><TrendingUp size={16} /> Progress</h3>
            <div className="h-40 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={vitalsHistory}>
                  <XAxis dataKey="week" hide />
                  <YAxis hide domain={['dataMin - 1', 'dataMax + 1']} />
                  <Line type="monotone" dataKey="weight" stroke="#A8C3B1" strokeWidth={3} dot={{r:4}} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </section>
        </div>
      )}

      {/* Medical Notes - New Editable Section for Instructor */}
      <section className="bg-white p-5 rounded-[2rem] border-2 border-dashed border-[#A8C3B1]/20">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-xs font-bold flex items-center gap-2 text-[#A8C3B1] uppercase"><Activity size={16} /> Medical Notes</h3>
          {user.role === 'INSTRUCTOR' && (
            <button onClick={() => isEditingNotes ? saveNotes() : setIsEditingNotes(true)} className="text-[#A8C3B1]"><Edit3 size={14} /></button>
          )}
        </div>
        {isEditingNotes ? (
          <textarea className="w-full p-4 bg-gray-50 rounded-2xl text-xs outline-none h-24" value={medicalNotes} onChange={e => setMedicalNotes(e.target.value)} placeholder="Enter clinical observations..." />
        ) : (
          <p className="text-[11px] text-gray-500 italic leading-relaxed">{medicalNotes || "No medical notes recorded yet."}</p>
        )}
      </section>
    </div>
  );
};

export default Tracking;
