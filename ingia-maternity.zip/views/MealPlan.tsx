
import React, { useState, useEffect } from 'react';
import { UserProfile, AppContent, Recommendation } from '../types';
import { CheckCircle2, ShoppingBasket, Info, Circle, Edit3, Trash2, Plus, Save, X, Droplet } from 'lucide-react';

const MealPlan: React.FC<{ user: UserProfile }> = ({ user }) => {
  const [appContent, setAppContent] = useState<AppContent>(() => {
    const saved = localStorage.getItem('ingia_app_content');
    return saved ? JSON.parse(saved) : {
      mealChecklist: [],
      vitaminText: 'Vitamin Reminder',
      vitaminTime: 'Daily, 8:00 PM',
      selfCareMedia: [],
      recommendations: []
    };
  });

  const [checklistStatus, setChecklistStatus] = useState<{ id: number; completed: boolean }[]>(() => {
    const saved = localStorage.getItem('ingia_meal_checklist_status');
    const today = new Date().toDateString();
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.date === today) return parsed.items;
    }
    return appContent.mealChecklist.map(item => ({ id: item.id, completed: false }));
  });

  const [waterGlasses, setWaterGlasses] = useState(() => {
    const saved = localStorage.getItem('ingia_water_intake');
    const today = new Date().toDateString();
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.date === today) return parsed.count;
    }
    return 0;
  });

  const [isEditing, setIsEditing] = useState(false);
  const [editingList, setEditingList] = useState(appContent.mealChecklist);
  const [editingRecs, setEditingRecs] = useState<Recommendation[]>(appContent.recommendations || []);

  useEffect(() => {
    localStorage.setItem('ingia_meal_checklist_status', JSON.stringify({
      date: new Date().toDateString(),
      items: checklistStatus
    }));
  }, [checklistStatus]);

  useEffect(() => {
    localStorage.setItem('ingia_water_intake', JSON.stringify({
      date: new Date().toDateString(),
      count: waterGlasses
    }));
  }, [waterGlasses]);

  const toggleItem = (id: number) => {
    if (user.role === 'INSTRUCTOR') return;
    setChecklistStatus(prev => prev.map(item => 
      item.id === id ? { ...item, completed: !item.completed } : item
    ));
  };

  const handleSaveAll = () => {
    const updatedContent = { 
      ...appContent, 
      mealChecklist: editingList,
      recommendations: editingRecs
    };
    setAppContent(updatedContent);
    localStorage.setItem('ingia_app_content', JSON.stringify(updatedContent));
    
    // Reset statuses for new list
    setChecklistStatus(editingList.map(item => ({ id: item.id, completed: false })));
    setIsEditing(false);
  };

  // Checklist Helpers
  const addItem = () => {
    setEditingList([...editingList, { id: Date.now(), label: 'New Meal Item' }]);
  };

  const removeItem = (id: number) => {
    setEditingList(editingList.filter(item => item.id !== id));
  };

  const updateItemLabel = (id: number, label: string) => {
    setEditingList(editingList.map(item => item.id === id ? { ...item, label } : item));
  };

  // Recommendation Helpers
  const addRecCategory = () => {
    const colors = ['border-blue-200', 'border-red-200', 'border-green-200', 'border-orange-200', 'border-purple-200'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    setEditingRecs([...editingRecs, { type: 'New Category', items: ['Item 1'], color: randomColor }]);
  };

  const removeRecCategory = (index: number) => {
    setEditingRecs(editingRecs.filter((_, i) => i !== index));
  };

  const updateRecType = (index: number, type: string) => {
    const newRecs = [...editingRecs];
    newRecs[index].type = type;
    setEditingRecs(newRecs);
  };

  const addRecItem = (recIndex: number) => {
    const newRecs = [...editingRecs];
    newRecs[recIndex].items.push('New Item');
    setEditingRecs(newRecs);
  };

  const removeRecItem = (recIndex: number, itemIndex: number) => {
    const newRecs = [...editingRecs];
    newRecs[recIndex].items = newRecs[recIndex].items.filter((_, i) => i !== itemIndex);
    setEditingRecs(newRecs);
  };

  const updateRecItemText = (recIndex: number, itemIndex: number, text: string) => {
    const newRecs = [...editingRecs];
    newRecs[recIndex].items[itemIndex] = text;
    setEditingRecs(newRecs);
  };

  const totalWater = 8;

  return (
    <div className="space-y-6 animate-fadeIn pb-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Nutrition & Meals</h2>
        {user.role === 'INSTRUCTOR' && (
          <button 
            onClick={() => {
              if (!isEditing) {
                setEditingList(appContent.mealChecklist);
                setEditingRecs(appContent.recommendations || []);
              }
              setIsEditing(!isEditing);
            }}
            className={`p-3 rounded-2xl flex items-center gap-2 text-xs font-bold transition-all shadow-sm ${isEditing ? 'bg-gray-100 text-gray-500' : 'bg-[#A8C3B1] text-white'}`}
          >
            {isEditing ? <X size={16} /> : <Edit3 size={16} />}
            {isEditing ? 'Cancel' : 'Edit Plan'}
          </button>
        )}
      </div>

      <div className="bg-[#E3F6E3] p-5 rounded-[2.5rem] border border-white shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Droplet size={18} className="text-[#A8C3B1]" />
          <h3 className="text-[10px] font-bold uppercase tracking-widest text-[#A8C3B1]">Daily Hydration</h3>
        </div>
        <div className="flex flex-wrap gap-2 justify-center mb-4">
          {Array.from({ length: totalWater }).map((_, i) => (
            <button 
              key={i} 
              onClick={() => user.role !== 'INSTRUCTOR' && setWaterGlasses(i + 1)}
              className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all active:scale-90 ${
                i < waterGlasses ? 'bg-blue-400 text-white shadow-md' : 'bg-white text-blue-200'
              }`}
            >
              <Droplet size={16} />
            </button>
          ))}
        </div>
        <p className="text-center text-[11px] font-bold text-[#3E3E3E]/60">
          {waterGlasses} / {totalWater} glasses today
        </p>
      </div>

      {isEditing ? (
        <div className="space-y-8 animate-slideInUp">
          {/* Checklist Editor */}
          <section className="bg-white rounded-[2rem] p-5 shadow-lg border-2 border-[#A8C3B1]/30">
            <h3 className="text-sm font-bold uppercase text-[#A8C3B1] mb-4">Edit Daily Checklist</h3>
            <div className="space-y-3 mb-4">
              {editingList.map((item) => (
                <div key={item.id} className="flex items-center gap-2 bg-gray-50 p-2 rounded-2xl">
                  <input 
                    type="text"
                    value={item.label}
                    onChange={(e) => updateItemLabel(item.id, e.target.value)}
                    className="flex-1 bg-transparent border-none font-bold text-sm outline-none px-2"
                  />
                  <button onClick={() => removeItem(item.id)} className="p-2 text-red-400">
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
              <button 
                onClick={addItem}
                className="w-full p-3 rounded-2xl border-2 border-dashed border-gray-200 text-gray-400 flex items-center justify-center gap-2 text-xs font-bold"
              >
                <Plus size={16} /> Add Checklist Item
              </button>
            </div>
          </section>

          {/* Recommendations Editor */}
          <section className="bg-white rounded-[2rem] p-5 shadow-lg border-2 border-[#F3C6CF]/30">
            <h3 className="text-sm font-bold uppercase text-[#F3C6CF] mb-4">Edit Recommendations</h3>
            <div className="space-y-6">
              {editingRecs.map((rec, recIdx) => (
                <div key={recIdx} className="p-4 rounded-2xl border bg-gray-50/50 space-y-3">
                  <div className="flex items-center gap-2">
                    <input 
                      type="text"
                      value={rec.type}
                      onChange={(e) => updateRecType(recIdx, e.target.value)}
                      className="flex-1 bg-white border rounded-xl p-2 font-bold text-xs outline-none"
                      placeholder="Category Name"
                    />
                    <button onClick={() => removeRecCategory(recIdx)} className="p-2 text-red-400">
                      <Trash2 size={18} />
                    </button>
                  </div>
                  <div className="space-y-2 pl-4">
                    {rec.items.map((item, itemIdx) => (
                      <div key={itemIdx} className="flex items-center gap-2">
                        <input 
                          type="text"
                          value={item}
                          onChange={(e) => updateRecItemText(recIdx, itemIdx, e.target.value)}
                          className="flex-1 bg-white border rounded-lg p-2 text-[11px] outline-none"
                        />
                        <button onClick={() => removeRecItem(recIdx, itemIdx)} className="p-1 text-gray-300 hover:text-red-400">
                          <X size={14} />
                        </button>
                      </div>
                    ))}
                    <button 
                      onClick={() => addRecItem(recIdx)}
                      className="text-[10px] font-bold text-[#A8C3B1] flex items-center gap-1 mt-2"
                    >
                      <Plus size={14} /> Add Suggestion
                    </button>
                  </div>
                </div>
              ))}
              <button 
                onClick={addRecCategory}
                className="w-full p-3 rounded-2xl border-2 border-dashed border-gray-200 text-gray-400 flex items-center justify-center gap-2 text-xs font-bold"
              >
                <Plus size={16} /> Add Recommendation Category
              </button>
            </div>
          </section>

          <button 
            onClick={handleSaveAll}
            className="w-full bg-[#A8C3B1] text-white p-5 rounded-[2rem] font-bold flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"
          >
            <Save size={20} /> Save All Nutrition Content
          </button>
        </div>
      ) : (
        <>
          <section className="bg-white rounded-[2rem] p-5 shadow-sm border border-gray-50">
            <h3 className="text-sm font-bold uppercase text-[#A8C3B1] mb-4 flex items-center gap-2">
               Daily Checklist
            </h3>
            <div className="space-y-3">
              {appContent.mealChecklist.map((item) => {
                const status = checklistStatus.find(s => s.id === item.id)?.completed;
                return (
                  <button 
                    key={item.id} 
                    onClick={() => toggleItem(item.id)}
                    disabled={user.role === 'INSTRUCTOR'}
                    className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all active:scale-[0.98] border-2 ${
                      status ? 'bg-[#E3F6E3]/40 border-transparent' : 'bg-white border-gray-50'
                    }`}
                  >
                    <span className={`text-xs font-bold ${status ? 'text-[#3E3E3E]/50 line-through' : 'text-[#3E3E3E]'}`}>
                      {item.label}
                    </span>
                    {status ? (
                      <CheckCircle2 size={22} className="text-[#A8C3B1]" />
                    ) : (
                      <Circle size={22} className="text-gray-200" />
                    )}
                  </button>
                );
              })}
              {appContent.mealChecklist.length === 0 && (
                <p className="text-center text-xs text-gray-300 italic py-4">No meal items set.</p>
              )}
            </div>
          </section>

          <section className="space-y-4">
            <h3 className="text-sm font-bold uppercase text-[#A8C3B1] flex items-center gap-2 ml-1">
              <ShoppingBasket size={18} /> Recommended Today
            </h3>
            <div className="grid grid-cols-1 gap-3">
              {(appContent.recommendations || []).map((rec, i) => (
                <div key={i} className={`bg-white p-5 rounded-[2rem] shadow-sm border-l-4 ${rec.color} hover:shadow-md transition-shadow`}>
                  <h4 className="text-[10px] font-bold text-[#3E3E3E]/40 uppercase mb-2 tracking-wide">{rec.type}</h4>
                  <div className="flex flex-wrap gap-2">
                    {rec.items.map(item => (
                      <span key={item} className="bg-[#B7E4C7]/20 px-3 py-1 rounded-full text-[11px] font-bold text-[#3E3E3E]">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
              {(!appContent.recommendations || appContent.recommendations.length === 0) && (
                <p className="text-center text-xs text-gray-300 italic py-4">No recommendations set.</p>
              )}
            </div>
          </section>
        </>
      )}
    </div>
  );
};

export default MealPlan;
