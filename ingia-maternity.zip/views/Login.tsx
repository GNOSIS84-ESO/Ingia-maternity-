
import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Smartphone, Lock, ChevronLeft, LogIn, AlertCircle } from 'lucide-react';
import Logo from '../components/Logo';

interface LoginProps {
  onSuccess: (user: UserProfile) => void;
  onForgotPassword: () => void;
  onBack: () => void;
  t: (key: string) => string;
}

const Login: React.FC<LoginProps> = ({ onSuccess, onForgotPassword, onBack, t }) => {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const database = JSON.parse(localStorage.getItem('ingia_database') || '[]');
    const user = database.find((u: UserProfile) => u.phone === phone && u.password === password);

    if (user) {
      onSuccess(user);
    } else {
      setError(t('incorrect_credentials'));
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-full animate-fadeIn p-6">
      <button 
        onClick={onBack}
        className="absolute top-8 left-6 p-3 bg-white rounded-full shadow-sm text-[#3E3E3E] active:scale-90 transition-transform"
      >
        <ChevronLeft size={20} />
      </button>

      <div className="mb-10 flex flex-col items-center">
        <Logo size="sm" className="mb-4" />
        <h1 className="text-2xl font-bold text-[#3E3E3E]">{t('sign_in')}</h1>
      </div>

      <div className="bg-white p-8 rounded-[3rem] shadow-xl w-full border border-[#F3C6CF]/20 space-y-6">
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-[10px] uppercase font-bold text-[#A8C3B1] mb-2 ml-1">{t('phone_number')}</label>
            <div className="relative">
              <input 
                type="tel" 
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-[#E3F6E3]/30 border-none rounded-2xl p-4 pl-12 text-sm outline-none focus:ring-2 focus:ring-[#F7B7A3]"
                placeholder="0712..."
              />
              <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 text-[#A8C3B1]" size={18} />
            </div>
          </div>

          <div>
            <label className="block text-[10px] uppercase font-bold text-[#A8C3B1] mb-2 ml-1">{t('password')}</label>
            <div className="relative">
              <input 
                type="password" 
                maxLength={4}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#E3F6E3]/30 border-none rounded-2xl p-4 pl-12 text-sm outline-none focus:ring-2 focus:ring-[#F7B7A3] font-bold tracking-[0.5em]"
                placeholder="****"
              />
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-[#A8C3B1]" size={18} />
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 text-red-500 text-xs font-bold animate-pulse bg-red-50 p-3 rounded-xl">
              <AlertCircle size={14} />
              {error}
            </div>
          )}

          <button 
            type="submit"
            className="w-full bg-[#F7B7A3] text-white p-4 rounded-2xl font-bold shadow-md active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <LogIn size={20} /> {t('sign_in')}
          </button>
        </form>

        <button 
          onClick={onForgotPassword}
          className="w-full text-[#3E3E3E]/40 text-xs font-bold uppercase tracking-widest text-center"
        >
          {t('forgot_password')}
        </button>
      </div>
    </div>
  );
};

export default Login;
