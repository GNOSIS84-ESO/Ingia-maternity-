
import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, AppContent, SelfCareMedia, EduItem, Language } from '../types';
import { Play, Wind, ShieldAlert, Smile, Plus, Trash2, Image as ImageIcon, Video, X, Save, ExternalLink, Upload, Loader2, Info, Edit3 } from 'lucide-react';

const MentalHealth: React.FC<{ user: UserProfile, t: (k: string) => string }> = ({ user, t }) => {
  const [isBreathing, setIsBreathing] = useState(false);
  const [showAddMedia, setShowAddMedia] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [newMedia, setNewMedia] = useState<Partial<SelfCareMedia>>({ type: 'image', url: '', title: '' });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [appContent, setAppContent] = useState<AppContent>(() => {
    const saved = localStorage.getItem('ingia_app_content');
    return saved ? JSON.parse(saved) : {
      mealChecklist: [],
      vitaminText: 'Vitamin Reminder',
      vitaminTime: 'Daily, 8:00 PM',
      selfCareMedia: [],
      eduContent: []
    };
  });

  const [selectedMood, setSelectedMood] = useState(() => {
    const saved = localStorage.getItem('ingia_current_mood');
    const today = new Date().toDateString();
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.date === today) return parsed.mood;
    }
    return null;
  });

  const moods = [
    { emoji: '😔', label: user.language === 'English' ? 'Sad' : 'Huzuni' },
    { emoji: '😐', label: user.language === 'English' ? 'Okay' : 'Sawa' },
    { emoji: '😊', label: user.language === 'English' ? 'Happy' : 'Furaha' },
    { emoji: '🥰', label: user.language === 'English' ? 'Loved' : 'Upendo' },
    { emoji: '😴', label: user.language === 'English' ? 'Tired' : 'Chovu' }
  ];

  // Educational Content Management
  const [isEditingEdu, setIsEditingEdu] = useState(false);
  const [tempEdu, setTempEdu] = useState<EduItem[]>(appContent.eduContent || []);

  const handleMoodSelect = (mood: string) => {
    if (user.role === 'INSTRUCTOR') return;
    setSelectedMood(mood);
    localStorage.setItem('ingia_current_mood', JSON.stringify({
      date: new Date().toDateString(),
      mood: mood
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("File is too large. For demo purposes, please upload files smaller than 5MB.");
      return;
    }

    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      setNewMedia({
        ...newMedia,
        url: event.target?.result as string,
        type: file.type.startsWith('video/') ? 'video' : 'image'
      });
      setIsUploading(false);
    };
    reader.onerror = () => {
      alert("Error reading file.");
      setIsUploading(false);
    };
    reader.readAsDataURL(file);
  };

  const handleSaveMedia = () => {
    if (!newMedia.url || !newMedia.title) {
      alert("Please provide a title and select a file.");
      return;
    }
    const media: SelfCareMedia = {
      id: Date.now().toString(),
      type: newMedia.type as 'image' | 'video',
      url: newMedia.url,
      title: newMedia.title
    };
    const updated = { ...appContent, selfCareMedia: [...appContent.selfCareMedia, media] };
    setAppContent(updated);
    localStorage.setItem('ingia_app_content', JSON.stringify(updated));
    setNewMedia({ type: 'image', url: '', title: '' });
    setShowAddMedia(false);
  };

  const deleteMedia = (id: string) => {
    if (window.confirm("Delete this media?")) {
      const updated = { ...appContent, selfCareMedia: appContent.selfCareMedia.filter(m => m.id !== id) };
      setAppContent(updated);
      localStorage.setItem('ingia_app_content', JSON.stringify(updated));
    }
  };

  // Edu Helpers
  const addEduItem = () => {
    const newItem: EduItem = {
      id: `edu-${Date.now()}`,
      title: { English: 'New Education Title', Swahili: 'Kichwa Kipya' },
      description: { English: 'Enter description here.', Swahili: 'Andika maelezo hapa.' },
      iconType: 'info'
    };
    setTempEdu([...tempEdu, newItem]);
  };

  const removeEduItem = (id: string) => {
    setTempEdu(tempEdu.filter(item => item.id !== id));
  };

  // Fix: Added missing 'Language' import from types.ts at line 2
  const updateEduField = (id: string, field: 'title' | 'description', lang: Language, value: string) => {
    setTempEdu(tempEdu.map(item => {
      if (item.id === id) {
        return {
          ...item,
          [field]: { ...item[field], [lang]: value }
        };
      }
      return item;
    }));
  };

  const updateEduIcon = (id: string, iconType: 'alert' | 'smile' | 'info') => {
    setTempEdu(tempEdu.map(item => item.id === id ? { ...item, iconType } : item));
  };

  const handleSaveEdu = () => {
    const updated = { ...appContent, eduContent: tempEdu };
    setAppContent(updated);
    localStorage.setItem('ingia_app_content', JSON.stringify(updated));
    setIsEditingEdu(false);
    alert("Educational content saved successfully.");
  };

  const getEduIcon = (type: string) => {
    switch (type) {
      case 'alert': return ShieldAlert;
      case 'smile': return Smile;
      default: return Info;
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{t('self_care')}</h2>
        {user.role === 'INSTRUCTOR' && (
          <button 
            onClick={() => setShowAddMedia(true)}
            className="bg-[#A8C3B1] text-white p-3 rounded-2xl flex items-center gap-2 text-xs font-bold shadow-sm active:scale-95 transition-all"
          >
            <Plus size={16} /> {t('add_media')}
          </button>
        )}
      </div>

      {/* Mood Tracker */}
      <section className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-[#A8C3B1]/20">
        <h3 className="text-sm font-bold uppercase text-[#A8C3B1] mb-4 text-center">
          {user.language === 'English' ? 'How are you feeling, Mama?' : 'Unajisikiaje leo, Mama?'}
        </h3>
        <div className="flex justify-between items-center px-2">
          {moods.map((m, i) => (
            <button 
              key={i} 
              onClick={() => handleMoodSelect(m.emoji)}
              disabled={user.role === 'INSTRUCTOR'}
              className={`w-12 h-12 rounded-2xl flex flex-col items-center justify-center text-2xl transition-all active:scale-90 ${
                selectedMood === m.emoji ? 'bg-[#F3C6CF] scale-110 shadow-md ring-2 ring-white' : 'bg-[#E3F6E3]'
              }`}
              title={m.label}
            >
              {m.emoji}
            </button>
          ))}
        </div>
      </section>

      {/* Guided Exercise */}
      <section 
        className={`p-6 rounded-[2.5rem] transition-all duration-500 overflow-hidden relative shadow-md ${
          isBreathing ? 'bg-[#A8C3B1] scale-[1.02]' : 'bg-[#F7B7A3]'
        }`}
      >
        <div className="relative z-10 text-white">
          <div className="flex items-center gap-2 mb-2">
            <Wind size={20} />
            <span className="text-[10px] font-bold uppercase tracking-widest">
              {user.language === 'English' ? 'Guided Breathing' : 'Mazoezi ya Kupumua'}
            </span>
          </div>
          <h4 className="text-xl font-bold mb-4">
            {isBreathing 
              ? (user.language === 'English' ? 'Deep Inhale... Exhale' : 'Vuta pumzi... Toa') 
              : (user.language === 'English' ? 'Relieve Pregnancy Stress' : 'Punguza Msongo wa Mawazo')}
          </h4>
          <button 
            onClick={() => setIsBreathing(!isBreathing)}
            className="bg-white text-[#3E3E3E] px-6 py-3 rounded-full font-bold flex items-center gap-2 shadow-sm transition-transform active:scale-95"
          >
            {isBreathing 
              ? (user.language === 'English' ? 'Finish Session' : 'Maliza Zoezi') 
              : <><Play size={16} fill="currentColor" /> {user.language === 'English' ? 'Start Now (2 min)' : 'Anza Sasa (Dk 2)'}</>}
          </button>
        </div>
        
        {isBreathing && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-64 h-64 bg-white/20 rounded-full animate-pulse"></div>
          </div>
        )}
      </section>

      {/* Instructor's Gallery */}
      <section className="space-y-4">
        <h3 className="text-sm font-bold uppercase text-[#A8C3B1] flex items-center gap-2 ml-1">
          <ImageIcon size={18} /> {t('instructor_gallery')}
        </h3>
        <div className="grid grid-cols-1 gap-4">
          {appContent.selfCareMedia.map((media) => (
            <div key={media.id} className="bg-white rounded-[2rem] overflow-hidden shadow-sm border border-gray-100 relative group">
              <div className="h-44 bg-gray-100 flex items-center justify-center relative">
                {media.type === 'image' ? (
                  <img src={media.url} alt={media.title} className="w-full h-full object-cover" />
                ) : (
                  <video src={media.url} className="w-full h-full object-cover" controls />
                )}
              </div>
              <div className="p-4 flex justify-between items-center">
                <div>
                  <h4 className="font-bold text-sm">{media.title}</h4>
                  <p className="text-[10px] text-[#3E3E3E]/40 uppercase font-bold">{media.type}</p>
                </div>
                {user.role === 'INSTRUCTOR' && (
                  <button onClick={() => deleteMedia(media.id)} className="p-2 text-red-400 hover:bg-red-50 rounded-full transition-colors">
                    <Trash2 size={18} />
                  </button>
                )}
              </div>
            </div>
          ))}
          {appContent.selfCareMedia.length === 0 && (
            <div className="bg-white p-10 rounded-[2rem] text-center border-2 border-dashed border-gray-100">
               <ImageIcon size={48} className="mx-auto mb-2 text-gray-200" />
               <p className="text-xs text-gray-300 italic font-bold">No gallery items yet.</p>
            </div>
          )}
        </div>
      </section>

      {/* Educational Content (Learn & Explore) */}
      <section className="space-y-4">
        <div className="flex justify-between items-center px-1">
          <h3 className="text-sm font-bold uppercase text-[#A8C3B1]">
            {user.language === 'English' ? 'Learn & Explore' : 'Jifunze Zaidi'}
          </h3>
          {user.role === 'INSTRUCTOR' && (
            <button 
              onClick={() => {
                if (!isEditingEdu) setTempEdu(appContent.eduContent || []);
                setIsEditingEdu(!isEditingEdu);
              }}
              className="text-[#A8C3B1] flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider"
            >
              {isEditingEdu ? <X size={14} /> : <Edit3 size={14} />}
              {isEditingEdu ? t('cancel') : 'Edit List'}
            </button>
          )}
        </div>

        {isEditingEdu ? (
          <div className="space-y-4 animate-slideInUp">
            {tempEdu.map((item) => (
              <div key={item.id} className="bg-white p-5 rounded-[2rem] shadow-lg border-2 border-[#A8C3B1]/20 space-y-4">
                <div className="flex justify-between items-center border-b pb-2">
                  <div className="flex gap-2">
                    {(['alert', 'smile', 'info'] as const).map(type => (
                      <button 
                        key={type} 
                        onClick={() => updateEduIcon(item.id, type)}
                        className={`p-2 rounded-xl transition-all ${item.iconType === type ? 'bg-[#A8C3B1] text-white shadow-sm' : 'bg-gray-50 text-gray-300'}`}
                      >
                        {type === 'alert' && <ShieldAlert size={16} />}
                        {type === 'smile' && <Smile size={16} />}
                        {type === 'info' && <Info size={16} />}
                      </button>
                    ))}
                  </div>
                  <button onClick={() => removeEduItem(item.id)} className="p-2 text-red-400">
                    <Trash2 size={16} />
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-3">
                  <div className="space-y-1">
                    <label className="text-[8px] font-bold text-gray-400 uppercase">Title (EN)</label>
                    <input 
                      className="w-full text-xs font-bold bg-gray-50 p-2 rounded-xl border-none outline-none"
                      value={item.title.English}
                      onChange={(e) => updateEduField(item.id, 'title', 'English', e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] font-bold text-gray-400 uppercase">Title (SW)</label>
                    <input 
                      className="w-full text-xs font-bold bg-gray-50 p-2 rounded-xl border-none outline-none"
                      value={item.title.Swahili}
                      onChange={(e) => updateEduField(item.id, 'title', 'Swahili', e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] font-bold text-gray-400 uppercase">Description (EN)</label>
                    <textarea 
                      className="w-full text-[10px] bg-gray-50 p-2 rounded-xl border-none outline-none h-16"
                      value={item.description.English}
                      onChange={(e) => updateEduField(item.id, 'description', 'English', e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] font-bold text-gray-400 uppercase">Description (SW)</label>
                    <textarea 
                      className="w-full text-[10px] bg-gray-50 p-2 rounded-xl border-none outline-none h-16"
                      value={item.description.Swahili}
                      onChange={(e) => updateEduField(item.id, 'description', 'Swahili', e.target.value)}
                    />
                  </div>
                </div>
              </div>
            ))}
            <button 
              onClick={addEduItem}
              className="w-full p-4 rounded-3xl border-2 border-dashed border-[#A8C3B1]/30 text-[#A8C3B1] flex items-center justify-center gap-2 text-xs font-bold"
            >
              <Plus size={16} /> Add New Edu Card
            </button>
            <button 
              onClick={handleSaveEdu}
              className="w-full bg-[#A8C3B1] text-white p-5 rounded-[2.5rem] font-bold flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"
            >
              <Save size={20} /> Save Educational Content
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {(appContent.eduContent || []).map((item) => {
              const IconComp = getEduIcon(item.iconType);
              return (
                <div key={item.id} className="bg-[#E3F6E3] p-4 rounded-[2rem] flex items-center gap-4 border border-white animate-fadeIn">
                  <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#A8C3B1] shadow-sm flex-shrink-0">
                    <IconComp size={24} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-bold">{user.language === 'English' ? item.title.English : item.title.Swahili}</p>
                    <p className="text-[10px] opacity-60 leading-tight">{user.language === 'English' ? item.description.English : item.description.Swahili}</p>
                  </div>
                </div>
              );
            })}
            {(!appContent.eduContent || appContent.eduContent.length === 0) && (
              <p className="text-center text-xs text-gray-300 italic py-4">No educational content set.</p>
            )}
          </div>
        )}
      </section>

      {/* Add Media Modal (Instructor Only) */}
      {showAddMedia && (
        <div className="fixed inset-0 z-[130] bg-black/60 backdrop-blur-sm flex items-end animate-fadeIn">
          <div className="bg-white w-full rounded-t-[3rem] p-8 shadow-2xl animate-slideInUp">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold">{t('add_media')}</h3>
              <button onClick={() => setShowAddMedia(false)} className="p-2 bg-gray-100 rounded-full">
                <X size={20} />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#A8C3B1] uppercase mb-1 ml-1">{t('media_title')}</label>
                <input 
                  type="text" 
                  value={newMedia.title}
                  onChange={(e) => setNewMedia({ ...newMedia, title: e.target.value })}
                  placeholder="e.g. Morning Meditation"
                  className="w-full bg-[#E3F6E3]/30 border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-[#F7B7A3] outline-none"
                />
              </div>
              
              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="block text-xs font-bold text-[#A8C3B1] uppercase mb-1 ml-1">{t('media_type')}</label>
                  <div className="flex gap-2">
                    {(['image', 'video'] as const).map((type) => (
                      <button
                        key={type}
                        onClick={() => setNewMedia({ ...newMedia, type })}
                        className={`flex-1 p-3 rounded-2xl border-2 font-bold text-xs transition-all ${
                          newMedia.type === type ? 'border-[#A8C3B1] bg-[#A8C3B1]/10 text-[#A8C3B1]' : 'border-gray-50 text-gray-400'
                        }`}
                      >
                        {type.toUpperCase()}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#A8C3B1] uppercase mb-1 ml-1">Upload from Device</label>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full bg-[#E3F6E3]/30 border-2 border-dashed border-[#A8C3B1]/30 rounded-2xl p-8 flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-[#E3F6E3]/50 transition-colors"
                >
                  {isUploading ? (
                    <Loader2 className="animate-spin text-[#A8C3B1]" size={32} />
                  ) : newMedia.url ? (
                    <div className="flex flex-col items-center gap-2">
                      {newMedia.type === 'image' ? (
                        <img src={newMedia.url} className="w-16 h-16 rounded-xl object-cover border" alt="Selected" />
                      ) : (
                        <Video className="text-[#A8C3B1]" size={32} />
                      )}
                      <span className="text-[10px] font-bold text-[#A8C3B1]">File Selected</span>
                    </div>
                  ) : (
                    <>
                      <Upload className="text-[#A8C3B1]" size={32} />
                      <span className="text-xs font-bold text-gray-400">Click to pick {newMedia.type}</span>
                    </>
                  )}
                </div>
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept={newMedia.type === 'image' ? "image/*" : "video/*"}
                  className="hidden" 
                />
              </div>

              <button 
                onClick={handleSaveMedia}
                disabled={!newMedia.url || !newMedia.title || isUploading}
                className={`w-full p-5 rounded-[2rem] font-bold shadow-lg flex items-center justify-center gap-2 transition-all mt-4 ${
                  !newMedia.url || !newMedia.title || isUploading ? 'bg-gray-300 cursor-not-allowed' : 'bg-[#F7B7A3] text-white active:scale-95'
                }`}
              >
                <Save size={20} /> {t('complete')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MentalHealth;
