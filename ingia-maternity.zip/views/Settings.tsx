
import React, { useRef, useState } from 'react';
import { UserProfile, Screen, Language, LiteracyMode, AppContent } from '../types';
import { User, LogOut, Shield, Languages, Eye, Info, Image as ImageIcon, Upload, Camera, Trash2, ChevronRight } from 'lucide-react';
import { requestCameraPermission } from '../utils/permissions';

interface SettingsProps {
  user: UserProfile;
  onUpdate: (u: UserProfile) => void;
  navigate: (s: Screen) => void;
  t: (key: string) => string;
}

const Settings: React.FC<SettingsProps> = ({ user, onUpdate, navigate, t }) => {
  const logoInputRef = useRef<HTMLInputElement>(null);

  const toggleLanguage = () => {
    const nextLang: Language = user.language === 'English' ? 'Swahili' : 'English';
    onUpdate({ ...user, language: nextLang });
  };

  const handleAccountDeletion = () => {
    const confirm = window.confirm("🚨 Account Deletion: This will permanently remove your medical profile and consultation history. This cannot be undone. Are you sure?");
    if (confirm) {
      localStorage.removeItem('ingia_user');
      // Also remove from global DB
      const db = JSON.parse(localStorage.getItem('ingia_database') || '[]');
      const filtered = db.filter((u: any) => u.phone !== user.phone);
      localStorage.setItem('ingia_database', JSON.stringify(filtered));
      window.location.reload();
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      <h2 className="text-2xl font-bold">{t('settings')}</h2>

      <section className="bg-white p-6 rounded-[2.5rem] shadow-sm flex items-center gap-4 border border-gray-50">
        <div className="w-16 h-16 rounded-full bg-[#B7E4C7] flex items-center justify-center border-4 border-[#E3F6E3]">
          <User size={32} className="text-[#3E3E3E]/40" />
        </div>
        <div>
          <h3 className="text-lg font-bold">{user.name}</h3>
          <p className="text-xs opacity-60">Week {user.weeksPregnant}</p>
        </div>
      </section>

      <div className="space-y-3">
        <h3 className="text-sm font-bold uppercase text-[#A8C3B1] px-2">App Preferences</h3>
        
        <button onClick={toggleLanguage} className="w-full bg-white p-5 rounded-[2rem] flex items-center justify-between shadow-sm active:scale-[0.98] transition-all">
          <div className="flex items-center gap-4">
            <Languages size={20} className="text-[#A8C3B1]" />
            <span className="text-sm font-bold">{t('language')}</span>
          </div>
          <span className="text-xs font-bold text-[#F7B7A3] bg-[#F7B7A3]/10 px-3 py-1 rounded-full">{user.language}</span>
        </button>

        <div className="bg-white p-5 rounded-[2.5rem] shadow-sm space-y-4">
          <div className="flex items-center gap-4">
            <Eye size={20} className="text-[#A8C3B1]" />
            <span className="text-sm font-bold">{t('literacy')}</span>
          </div>
          <div className="flex gap-2">
            {['TEXT', 'VOICE', 'PICTURE'].map((mode) => (
              <button
                key={mode}
                onClick={() => onUpdate({ ...user, literacyMode: mode as LiteracyMode })}
                className={`flex-1 py-3 rounded-2xl text-[10px] font-bold transition-all ${
                  user.literacyMode === mode ? 'bg-[#A8C3B1] text-white shadow-md' : 'bg-gray-100 text-[#3E3E3E]/40'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h3 className="text-sm font-bold uppercase text-[#A8C3B1] px-2">Security & Privacy</h3>
        
        <button onClick={() => navigate(Screen.PRIVACY_POLICY)} className="w-full bg-white p-5 rounded-[2rem] flex items-center justify-between shadow-sm active:scale-[0.98] transition-all">
          <div className="flex items-center gap-4">
            <Shield size={20} className="text-[#A8C3B1]" />
            <span className="text-sm font-bold">Privacy Policy</span>
          </div>
          <ChevronRight size={18} className="text-gray-300" />
        </button>

        <button onClick={() => navigate(Screen.ABOUT)} className="w-full bg-white p-5 rounded-[2rem] flex items-center justify-between shadow-sm active:scale-[0.98] transition-all">
          <div className="flex items-center gap-4">
            <Info size={20} className="text-[#A8C3B1]" />
            <span className="text-sm font-bold">{t('about_app')}</span>
          </div>
          <ChevronRight size={18} className="text-gray-300" />
        </button>

        <button onClick={handleAccountDeletion} className="w-full bg-red-50 p-5 rounded-[2rem] flex items-center gap-4 text-red-500 active:scale-[0.98] transition-all border border-red-100">
          <Trash2 size={20} />
          <span className="text-sm font-bold">Request Data Deletion</span>
        </button>
      </div>

      <button onClick={() => { localStorage.removeItem('ingia_user'); window.location.reload(); }} className="w-full p-5 rounded-[2rem] text-[#3E3E3E] font-bold border-2 border-gray-200 flex items-center justify-center gap-3 mt-4">
        <LogOut size={20} /> {t('logout')}
      </button>
    </div>
  );
};

export default Settings;
