
import React, { useState, useEffect } from 'react';
import { Screen, UserProfile, Language, translations, AppContent } from './types';
import Registration from './views/Registration';
import Dashboard from './views/Dashboard';
import Tracking from './views/Tracking';
import MentalHealth from './views/MentalHealth';
import Consultation from './views/Consultation';
import MealPlan from './views/MealPlan';
import Payment from './views/Payment';
import Settings from './views/Settings';
import RoleSelection from './views/RoleSelection';
import AuthChoice from './views/AuthChoice';
import Login from './views/Login';
import PasswordReset from './views/PasswordReset';
import Database from './views/Database';
import Notifications from './views/Notifications';
import About from './views/About';
import PrivacyPolicy from './views/PrivacyPolicy';
import Header from './components/Header';
import BottomNav from './components/BottomNav';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>(Screen.ROLE_SELECTION);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('ingia_user');
    if (saved) {
      setUserProfile(JSON.parse(saved));
      setCurrentScreen(Screen.DASHBOARD);
    }

    const appContentStr = localStorage.getItem('ingia_app_content');
    if (!appContentStr) {
      const initialContent: AppContent = {
        logoUrl: "https://cdn-icons-png.flaticon.com/512/3663/3663335.png",
        welcomeMessage: {
          English: "Let's set up your personalized care.",
          Swahili: "Hebu tuandae huduma yako binafsi."
        },
        mealChecklist: [
          { id: 1, label: 'Healthy Breakfast' },
          { id: 2, label: 'Morning Snack (Fruits)' },
          { id: 3, label: 'Iron-Rich Lunch' },
          { id: 4, label: 'Evening Milk/Protein' },
          { id: 5, label: 'Balanced Dinner' }
        ],
        vitaminText: 'Vitamin Reminder',
        vitaminTime: 'Daily, 8:00 PM',
        selfCareMedia: [],
        globalNotification: {
          message: 'Welcome to Ingia Maternity! We are here to support your journey.',
          timestamp: new Date().toISOString(),
          author: 'System'
        },
        about: {
          description: 'Ingia Maternity is a supportive digital health platform for expectant mothers, offering pregnancy tracking, mental health support, and expert consultations with a focus on accessibility.',
          attachments: []
        },
        dailyInsight: {
          English: "Eat small, frequent meals to help with morning sickness. Ginger tea can also be a wonderful natural remedy!",
          Swahili: "Kula milo midogo mara kwa mara kusaidia kichefuchefu cha asubuhi. Chai ya tangawizi pia inaweza kuwa dawa nzuri ya asili!"
        },
        recommendations: [
          { type: 'Protein', items: ['Lentils', 'Eggs', 'Chicken', 'Beans'], color: 'border-blue-200' },
          { type: 'Iron & Folate', items: ['Spinach', 'Fortified Cereals', 'Liver'], color: 'border-red-200' },
          { type: 'Healthy Fats', items: ['Avocado', 'Nuts', 'Olive Oil'], color: 'border-green-200' }
        ],
        eduContent: [
          { 
            id: 'edu-1',
            title: { English: 'Understanding Baby Blues', Swahili: 'Kuelewa Hali Baada ya Uzazi' }, 
            description: { English: 'Why you might feel weepy after birth.', Swahili: 'Kwa nini unaweza kujihisi mnyonge baada ya kujifungua.' }, 
            iconType: 'alert' 
          },
          { 
            id: 'edu-2',
            title: { English: 'Connecting with Baby', Swahili: 'Kuungana na Mtoto' }, 
            description: { English: 'Mindfulness tips for early bonding.', Swahili: 'Vidokezo vya kuungana na mtoto wako ukiwa mjamzito.' }, 
            iconType: 'smile' 
          }
        ]
      };
      localStorage.setItem('ingia_app_content', JSON.stringify(initialContent));
    }
  }, []);

  const handleRegistrationComplete = async (profile: UserProfile) => {
    const timeStampedProfile = { ...profile, updatedAt: new Date().toISOString() };
    setUserProfile(timeStampedProfile);
    localStorage.setItem('ingia_user', JSON.stringify(timeStampedProfile));
    
    const database = JSON.parse(localStorage.getItem('ingia_database') || '[]');
    const filteredDb = database.filter((u: UserProfile) => u.phone !== profile.phone);
    filteredDb.push(timeStampedProfile);
    localStorage.setItem('ingia_database', JSON.stringify(filteredDb));
    
    setCurrentScreen(Screen.DASHBOARD);
  };

  const handleLoginSuccess = (profile: UserProfile) => {
    setUserProfile(profile);
    localStorage.setItem('ingia_user', JSON.stringify(profile));
    setCurrentScreen(Screen.DASHBOARD);
  };

  const handleInstructorLogin = () => {
    const staffProfile: UserProfile = {
      id: 'staff-leonia',
      role: 'INSTRUCTOR',
      name: 'Midwife Leonia',
      phone: '777847',
      email: 'leonia@ingia.co.tz',
      age: 40,
      location: 'Dar es Salaam HQ',
      weeksPregnant: 0,
      pregnancyEntryValue: 0,
      pregnancyEntryUnit: 'WEEKS',
      registrationDate: new Date().toISOString(),
      pregnanciesCount: 0,
      liveBirths: 0,
      livingChildren: 0,
      abortionsMiscarriages: 0,
      emergencyContact: '+255000000000',
      language: 'English',
      literacyMode: 'TEXT',
      bloodGroup: 'O+',
      lnmp: 'N/A',
      chronicDiseases: []
    };
    setUserProfile(staffProfile);
    localStorage.setItem('ingia_user', JSON.stringify(staffProfile));
    setCurrentScreen(Screen.DASHBOARD);
  };

  const t = (key: string) => {
    const lang: Language = userProfile?.language || 'English';
    return translations[lang][key] || key;
  };

  const renderScreen = () => {
    if (currentScreen === Screen.ROLE_SELECTION) {
      return <RoleSelection onRecipientChoice={() => setCurrentScreen(Screen.AUTH_CHOICE)} onInstructorAuth={handleInstructorLogin} t={t} />;
    }

    switch (currentScreen) {
      case Screen.AUTH_CHOICE: return <AuthChoice onSignIn={() => setCurrentScreen(Screen.LOGIN)} onSignUp={() => setCurrentScreen(Screen.REGISTRATION)} onBack={() => setCurrentScreen(Screen.ROLE_SELECTION)} t={t} />;
      case Screen.LOGIN: return <Login onSuccess={handleLoginSuccess} onForgotPassword={() => setCurrentScreen(Screen.PASSWORD_RESET)} onBack={() => setCurrentScreen(Screen.AUTH_CHOICE)} t={t} />;
      case Screen.REGISTRATION: return <Registration onComplete={handleRegistrationComplete} onCancel={() => setCurrentScreen(Screen.AUTH_CHOICE)} />;
      case Screen.DASHBOARD: return <Dashboard user={userProfile!} navigate={setCurrentScreen} t={t} />;
      case Screen.TRACKING: return <Tracking user={userProfile!} />;
      case Screen.MENTAL_HEALTH: return <MentalHealth user={userProfile!} t={t} />;
      case Screen.CONSULTATION: return <Consultation user={userProfile!} t={t} />;
      case Screen.MEAL_PLAN: return <MealPlan user={userProfile!} />;
      case Screen.PAYMENT: return <Payment user={userProfile!} navigate={setCurrentScreen} />;
      case Screen.SETTINGS: return <Settings user={userProfile!} onUpdate={(p) => { setUserProfile(p); localStorage.setItem('ingia_user', JSON.stringify(p)); }} navigate={setCurrentScreen} t={t} />;
      case Screen.DATABASE: return <Database t={t} user={userProfile!} />;
      case Screen.NOTIFICATIONS: return <Notifications user={userProfile!} t={t} onBack={() => setCurrentScreen(Screen.DASHBOARD)} />;
      case Screen.ABOUT: return <About user={userProfile!} t={t} onBack={() => setCurrentScreen(Screen.SETTINGS)} />;
      case Screen.PRIVACY_POLICY: return <PrivacyPolicy onBack={() => setCurrentScreen(Screen.SETTINGS)} t={t} />;
      default: return <Dashboard user={userProfile!} navigate={setCurrentScreen} t={t} />;
    }
  };

  const showNav = userProfile && ![Screen.REGISTRATION, Screen.ROLE_SELECTION, Screen.AUTH_CHOICE, Screen.LOGIN, Screen.PASSWORD_RESET].includes(currentScreen);

  return (
    <div className="min-h-screen bg-[#B7E4C7] flex flex-col max-w-md mx-auto shadow-2xl relative overflow-hidden">
      {showNav && <Header user={userProfile} currentScreen={currentScreen} onBack={() => setCurrentScreen(Screen.DASHBOARD)} onOpenSettings={() => setCurrentScreen(Screen.SETTINGS)} onOpenNotifications={() => setCurrentScreen(Screen.NOTIFICATIONS)} />}
      <main className={`flex-1 overflow-y-auto p-4 ${!showNav ? 'pt-8' : ''} ${showNav ? 'pb-24' : 'pb-6'}`}>
        {renderScreen()}
      </main>
      {showNav && <BottomNav activeScreen={currentScreen} onNavigate={setCurrentScreen} userRole={userProfile?.role} t={t} />}
    </div>
  );
};

export default App;
