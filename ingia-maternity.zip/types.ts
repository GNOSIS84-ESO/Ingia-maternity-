
export enum Screen {
  ROLE_SELECTION = 'ROLE_SELECTION',
  AUTH_CHOICE = 'AUTH_CHOICE',
  LOGIN = 'LOGIN',
  REGISTRATION = 'REGISTRATION',
  PASSWORD_RESET = 'PASSWORD_RESET',
  DASHBOARD = 'DASHBOARD',
  TRACKING = 'TRACKING',
  MENTAL_HEALTH = 'MENTAL_HEALTH',
  CONSULTATION = 'CONSULTATION',
  MEAL_PLAN = 'MEAL_PLAN',
  PAYMENT = 'PAYMENT',
  SETTINGS = 'SETTINGS',
  DATABASE = 'DATABASE',
  NOTIFICATIONS = 'NOTIFICATIONS',
  ABOUT = 'ABOUT',
  PRIVACY_POLICY = 'PRIVACY_POLICY'
}

export type LiteracyMode = 'TEXT' | 'VOICE' | 'PICTURE';
export type Language = 'English' | 'Swahili';
export type PregnancyUnit = 'DAYS' | 'WEEKS' | 'MONTHS';
export type UserRole = 'RECIPIENT' | 'INSTRUCTOR';

export interface ChatMessage {
  id: string;
  text: string;
  senderId: string;
  senderRole: UserRole;
  senderName: string;
  timestamp: string;
}

export interface SelfCareMedia {
  id: string;
  type: 'image' | 'video';
  url: string;
  title: string;
}

export interface AboutContent {
  description: string;
  attachments: { name: string; url: string }[];
}

export interface Recommendation {
  type: string;
  items: string[];
  color: string;
}

export interface EduItem {
  id: string;
  title: { English: string; Swahili: string };
  description: { English: string; Swahili: string };
  iconType: 'alert' | 'smile' | 'info';
}

export interface AppContent {
  logoUrl?: string;
  welcomeMessage: {
    English: string;
    Swahili: string;
  };
  mealChecklist: { id: number; label: string }[];
  vitaminText: string;
  vitaminTime: string;
  selfCareMedia: SelfCareMedia[];
  globalNotification: {
    message: string;
    timestamp: string;
    author: string;
  };
  about: AboutContent;
  dailyInsight: {
    English: string;
    Swahili: string;
    image?: string;
  };
  recommendations: Recommendation[];
  eduContent: EduItem[];
}

export interface UserProfile {
  id: string;
  role: UserRole;
  name: string;
  phone: string;
  password?: string;
  email: string;
  age: number;
  location: string;
  weeksPregnant: number;
  pregnancyEntryValue: number;
  pregnancyEntryUnit: PregnancyUnit;
  registrationDate: string;
  updatedAt?: string; 
  pregnanciesCount: number;
  liveBirths: number;
  livingChildren: number;
  abortionsMiscarriages: number;
  emergencyContact: string;
  language: Language;
  literacyMode: LiteracyMode;
  bloodGroup: string;
  lnmp: string;
  chronicDiseases: string[];
  lastClinicVisit?: string;
  nextClinicVisit?: string;
}

export const translations: Record<Language, Record<string, string>> = {
  English: {
    home: 'Home',
    tracker: 'Tracker',
    meals: 'Meals',
    self_care: 'Self-Care',
    experts: 'Experts',
    welcome: 'Welcome, Mama',
    welcome_sub: "Let's set up your personalized care.",
    step: 'Step',
    of: 'of',
    next: 'Next Step',
    back: 'Back',
    complete: 'Complete',
    basic_info: 'Basic Information',
    your_name: 'Your Name',
    name_placeholder: 'How should we call you?',
    phone_number: 'Phone Number',
    phone_placeholder: 'M-Pesa / Mobile Money number',
    accessibility: 'Accessibility Mode',
    pregnancy_details: 'Pregnancy Details',
    pregnancy_age_label: 'How far along is your pregnancy?',
    weeks_pregnant: 'Weeks Pregnant',
    days: 'Days',
    weeks: 'Weeks',
    months: 'Months',
    location_ward: 'Location / Ward',
    lnmp: 'Last Menstrual Period (LNMP)',
    blood_group: 'Blood Group Type',
    chronic_diseases: 'Chronic Diseases',
    diseases_hint: 'Select any that apply (HIV, BP, TB, etc.)',
    history: 'Medical History',
    safety_consent: 'Safety & Consent',
    emergency_contact: 'Emergency Contact Number',
    emergency_placeholder: 'Partner, sister, or relative',
    privacy_agreement: 'Privacy Agreement',
    privacy_text: 'We protect your health data with high security. By clicking "Complete", you agree to share your information with Ingia Maternity.',
    language_selection: 'Preferred Language',
    week: 'Week',
    day: 'Day',
    trimester: 'Trimester',
    insight: 'Today\'s Insight',
    nutrition: 'Nutrition',
    health_log: 'Health Log',
    emergency_btn: 'Need Emergency Help?',
    emergency_desc: 'Call our expert for immediate assistance:',
    call_now: 'Call Now',
    settings: 'Settings',
    language: 'Language',
    literacy: 'Literacy Mode',
    logout: 'Logout',
    expert_intro: 'Hello Mama, I am Midwife LEONIA MSANGI.',
    expert_role: 'Professional Midwife',
    notifying: 'Securing your profile...',
    clinic_checkup: 'Clinic Check-up',
    last_clinic_visit: 'Last Clinic Visit',
    next_clinic_visit: 'Next Clinic Visit',
    edit_clinic_dates: 'Update Clinic Dates',
    save_dates: 'Save Dates',
    clinic_reminder_title: 'Clinic Reminder',
    clinic_reminder_msg: 'Mama, your next clinic visit is in 2 days!',
    no_date_set: 'No date set',
    vitamin_reminder: 'Vitamin Reminder',
    daily_vitamin: 'Daily, 8:00 PM',
    probation_date: 'Probation Date (EDD)',
    countdown_title: 'Countdown to Delivery',
    remaining: 'Remaining',
    age_now: 'Current Age',
    choose_role: 'Choose your role',
    recipients: 'RECIPIENTS',
    instructor: 'INSTRUCTOR',
    enter_pin: 'Enter Instructor PIN',
    incorrect_pin: 'Incorrect PIN. Please try again.',
    database: 'Records',
    recipient_files: 'Recipient Files',
    search_recipients: 'Search by name or phone...',
    admin_mode: 'Admin Mode Active',
    edit_content: 'Edit App Content',
    add_media: 'Add Media',
    media_title: 'Title',
    media_url: 'Image/Video URL',
    media_type: 'Type',
    instructor_gallery: 'Education Gallery',
    good_morning: 'Good Morning, Mama',
    good_afternoon: 'Good Afternoon, Mama',
    good_evening: 'Good Evening, Mama',
    good_night: 'Good Night, Mama',
    notifications_center: 'Notification Center',
    broadcast_message: 'Broadcast Message',
    broadcast_placeholder: 'Write a message for all mothers...',
    send_broadcast: 'Send to All Users',
    from_instructor: 'Message from Instructor',
    no_notifications: 'No new notifications',
    about_app: 'About App',
    app_description: 'App Description',
    attachments: 'PDF Attachments',
    add_attachment: 'Add PDF Link',
    attachment_name: 'File Name',
    attachment_url: 'PDF URL',
    active_chats: 'Active Consultations',
    no_chats: 'No active conversations',
    reply: 'Reply',
    chat_with: 'Chatting with',
    edit_insight: 'Edit Insight',
    upload_image: 'Upload Image',
    remove_image: 'Remove Image',
    image_too_large: 'Image size must be less than 2MB',
    sign_in: 'Sign In',
    sign_up: 'Sign Up',
    password: 'Password',
    password_hint: '4-digit security code',
    forgot_password: 'Forgot Password?',
    incorrect_credentials: 'Phone or Password incorrect.',
    reset_password: 'Reset Password',
    verify_identity: 'Verify Identity',
    verify_hint: 'Enter Phone and LNMP to reset password',
    new_password: 'New 4-Digit Password',
    edit_profile: 'Modify Recipient Data',
    save_changes: 'Save Changes',
    cancel: 'Cancel',
    modify_welcome: 'Edit Welcome Text',
    brand_mgmt: 'Brand Management',
    upload_logo: 'Update App Logo',
    my_records: 'My Health Records',
    db_mgmt: 'Database Management',
    export_db: 'Backup Database (JSON)',
    import_db: 'Restore Database',
    clear_db: 'Clear All Records',
    last_updated: 'Updated',
    medical_disclaimer: 'Disclaimer: This app provides support but is not a substitute for professional medical diagnosis. Always consult a clinic for medical emergencies.'
  },
  Swahili: {
    home: 'Nyumbani',
    tracker: 'Kifuatiliaji',
    meals: 'Chakula',
    self_care: 'Kujijali',
    experts: 'Wataalamu',
    welcome: 'Karibu, Mama',
    welcome_sub: 'Hebu tuandae huduma yako binafsi.',
    step: 'Hatua ya',
    of: 'kati ya',
    next: 'Hatua Inayofuata',
    back: 'Rudi Nyuma',
    complete: 'Kamilisha',
    basic_info: 'Habari za Msingi',
    your_name: 'Jina Lako',
    name_placeholder: 'Tukuite jina gani?',
    phone_number: 'Namba ya Simu',
    phone_placeholder: 'Namba ya M-Pesa / Mobile Money',
    accessibility: 'Njia ya Kutumia App',
    pregnancy_details: 'Taarifa za Ujauzito',
    pregnancy_age_label: 'Ujauzito una muda gani?',
    weeks_pregnant: 'Wiki za Ujauzito',
    days: 'Siku',
    weeks: 'Wiki',
    months: 'Miezi',
    location_ward: 'Mahali / Kata',
    lnmp: 'Tarehe ya Hedhi ya Mwisho (LNMP)',
    blood_group: 'Kundi la Damu',
    chronic_diseases: 'Magonjwa Sugu',
    diseases_hint: 'Chagua yanayokuhusu (VVU, BP, TB, n.k.)',
    history: 'Historia ya Matibabu',
    safety_consent: 'Usalama na Idhini',
    emergency_contact: 'Namba ya Simu ya Dharura',
    emergency_placeholder: 'Mwenzi, dada, au ndugu',
    privacy_agreement: 'Mkataba wa Faragha',
    privacy_text: 'Tunatunza data zako za afya kwa usalama mkubwa. Kwa kubonyeza "Kamilisha", unakubali kushiriki taarifa zako na Ingia Maternity.',
    language_selection: 'Lugha Unayopendelea',
    week: 'Wiki',
    day: 'Siku',
    trimester: 'Miezi mitatu ya',
    insight: 'Ushauri wa Leo',
    nutrition: 'Lishe',
    health_log: 'Rekodi ya Afya',
    emergency_btn: 'Unahitaji Msaada wa Dharura?',
    emergency_desc: 'Piga simu kwa mtaalamu wetu kwa msaada wa haraka:',
    call_now: 'Piga Simu Sasa',
    settings: 'Mipangilio',
    language: 'Lugha',
    literacy: 'Njia ya Kusoma',
    logout: 'Ondoka',
    expert_intro: 'Habari Mama, Mimi ni Mkufunzi LEONIA MSANGI.',
    expert_role: 'Mkunga Mtaalamu',
    notifying: 'Tunalinda wasifu wako...',
    clinic_checkup: 'Uchunguzi wa Kliniki',
    last_clinic_visit: 'Mahudhurio ya Mwisho',
    next_clinic_visit: 'Mahudhurio Yajayo',
    edit_clinic_dates: 'Badilisha Tarehe za Kliniki',
    save_dates: 'Hifadhi Tarehe',
    clinic_reminder_title: 'Kikumbusho cha Kliniki',
    clinic_reminder_msg: 'Mama, mahudhurio yako yajayo ya kliniki ni baada ya siku 2!',
    no_date_set: 'Tarehe haijawekwa',
    vitamin_reminder: 'Kikumbusho cha Vitamini',
    daily_vitamin: 'Kila siku, Saa 2:00 Usiku',
    probation_date: 'Tarehe ya Kujifungua (EDD)',
    countdown_title: 'Muda uliobaki',
    remaining: 'Imebaki',
    age_now: 'Umri wa Sasa',
    choose_role: 'Chagua jukumu lako',
    recipients: 'MAMA (WAPOKEWAJI)',
    instructor: 'MKUFUNZI',
    enter_pin: 'Ingiza PIN ya Mkufunzi',
    incorrect_pin: 'PIN si sahihi. Tafadhali jaribu tena.',
    database: 'Kumbukumbu',
    recipient_files: 'Faili za Wapokeaji',
    search_recipients: 'Tafuta kwa jina au simu...',
    admin_mode: 'Hali ya Msimamizi Imewashwa',
    edit_content: 'Hariri Maudhui ya App',
    add_media: 'Ongeza Picha/Video',
    media_title: 'Kichwa',
    media_url: 'Link ya Picha/Video',
    media_type: 'Aina',
    instructor_gallery: 'Maktaba ya Elimu',
    good_morning: 'Habari za Asubuhi, Mama',
    good_afternoon: 'Habari za Mchana, Mama',
    good_evening: 'Habari za Jioni, Mama',
    good_night: 'Usiku Mwema, Mama',
    notifications_center: 'Kituo cha Arifa',
    broadcast_message: 'Ujumbe kwa Wote',
    broadcast_placeholder: 'Andika ujumbe kwa mama wote...',
    send_broadcast: 'Tuma kwa Watumiaji Wote',
    from_instructor: 'Ujumbe kutoka kwa Mkufunzi',
    no_notifications: 'Hakuna arifa mpya',
    about_app: 'Kuhusu Programu',
    app_description: 'Maelezo ya Programu',
    attachments: 'Viambatisho vya PDF',
    add_attachment: 'Ongeza Link ya PDF',
    attachment_name: 'Jina la Faili',
    attachment_url: 'Link ya PDF',
    active_chats: 'Mazungumzo Yanayoendelea',
    no_chats: 'Hakuna mazungumzo mapya',
    reply: 'Jibu',
    chat_with: 'Unazungumza na',
    edit_insight: 'Hariri Ushauri',
    upload_image: 'Pakia Picha',
    remove_image: 'Ondoa Picha',
    image_too_large: 'Ukubwa wa picha uwe chini ya 2MB',
    sign_in: 'Ingia',
    sign_up: 'Jisajili',
    password: 'Nenosiri',
    password_hint: 'Namba 4 za siri',
    forgot_password: 'Umesahau Nenosiri?',
    incorrect_credentials: 'Simu au Nenosiri si sahihi.',
    reset_password: 'Badilisha Nenosiri',
    verify_identity: 'Thibitisha Utambulisho',
    verify_hint: 'Weka Simu na LNMP ili kubadili nenosiri',
    new_password: 'Nenosiri Jipya (Namba 4)',
    edit_profile: 'Hariri Taarifa za Mama',
    save_changes: 'Hifadhi Mabadiliko',
    cancel: 'Ghairi',
    modify_welcome: 'Hariri Maelezo ya Karibu',
    brand_mgmt: 'Usimamizi wa Chapa',
    upload_logo: 'Pakia Logo ya App',
    my_records: 'Kumbukumbu Zangu',
    db_mgmt: 'Usimamizi wa Database',
    export_db: 'Hifadhi Database (JSON)',
    import_db: 'Rejesha Database',
    clear_db: 'Futa Kumbukumbu Zote',
    last_updated: 'Ilihuishwa',
    medical_disclaimer: 'Onyo: Programu hii inatoa ushauri lakini si badala ya utambuzi wa kitaalamu wa daktari. Daima wasiliana na kliniki kwa dharura za matibabu.'
  }
};
