
import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const Logo: React.FC<LogoProps> = ({ className = '', size = 'md' }) => {
  const dimensions = {
    sm: 'w-10 h-10',
    md: 'w-24 h-24',
    lg: 'w-36 h-36'
  };

  // High quality brand logo URL
  const brandLogoUrl = "https://cdn-icons-png.flaticon.com/512/3663/3663335.png";

  return (
    <div className={`relative flex items-center justify-center ${dimensions[size]} bg-white rounded-[2rem] border-4 border-[#F3C6CF] shadow-lg overflow-hidden transition-transform hover:scale-105 ${className}`}>
      <div className="absolute inset-0 bg-gradient-to-br from-[#F3C6CF]/10 to-transparent"></div>
      <img 
        src={brandLogoUrl} 
        alt="Ingia Maternity Logo" 
        className="w-[80%] h-[80%] object-contain relative z-10" 
      />
    </div>
  );
};

export default Logo;
