
import React from 'react';
import { Screen, UserRole } from '../types';
import { Home, Calendar, Heart, MessageCircle, Utensils, Database } from 'lucide-react';

interface BottomNavProps {
  activeScreen: Screen;
  onNavigate: (screen: Screen) => void;
  userRole?: UserRole;
  t: (key: string) => string;
}

const BottomNav: React.FC<BottomNavProps> = ({ activeScreen, onNavigate, userRole, t }) => {
  const items = [
    { screen: Screen.DASHBOARD, icon: Home, label: t('home') },
    { screen: Screen.TRACKING, icon: Calendar, label: t('tracker') },
    { screen: Screen.MEAL_PLAN, icon: Utensils, label: t('meals') },
    { screen: Screen.MENTAL_HEALTH, icon: Heart, label: t('self_care') },
    { screen: Screen.CONSULTATION, icon: MessageCircle, label: t('experts') },
    { screen: Screen.DATABASE, icon: Database, label: userRole === 'INSTRUCTOR' ? t('database') : t('my_records') },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-[#A8C3B1]/30 px-2 pt-2 pb-2 flex flex-col items-center z-50 rounded-t-3xl shadow-lg">
      <div className="w-full flex justify-around items-center">
        {items.map(({ screen, icon: Icon, label }) => {
          const isActive = activeScreen === screen;
          return (
            <button
              key={screen}
              onClick={() => onNavigate(screen)}
              className={`flex flex-col items-center gap-0.5 transition-all duration-300 ${
                isActive ? 'text-[#F7B7A3] scale-110' : 'text-[#3E3E3E] opacity-60'
              }`}
            >
              <div className={`p-1 rounded-xl ${isActive ? 'bg-[#F7B7A3]/10' : ''}`}>
                <Icon size={isActive ? 22 : 18} strokeWidth={isActive ? 2.5 : 2} />
              </div>
              <span className={`text-[9px] font-bold ${isActive ? 'opacity-100' : 'opacity-80'}`}>
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
