
import React from 'react';
import { UserProfile, Screen } from '../types';
import { Settings, Bell, ChevronLeft, ShieldCheck } from 'lucide-react';
import Logo from './Logo';

interface HeaderProps {
  user: UserProfile | null;
  currentScreen: Screen;
  onBack: () => void;
  onOpenSettings: () => void;
  onOpenNotifications: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, currentScreen, onBack, onOpenSettings, onOpenNotifications }) => {
  const isDashboard = currentScreen === Screen.DASHBOARD;
  const isInstructor = user?.role === 'INSTRUCTOR';

  return (
    <header className="bg-transparent px-4 pt-4 pb-2 flex items-center justify-between sticky top-0 z-50 backdrop-blur-md">
      <div className="flex items-center gap-3">
        {isDashboard ? (
          <Logo size="sm" />
        ) : (
          <button 
            onClick={onBack}
            className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm text-[#3E3E3E] active:scale-90 transition-transform border border-gray-100"
          >
            <ChevronLeft size={24} />
          </button>
        )}
        <div>
          <div className="flex items-center gap-1.5">
            <h1 className="text-lg font-bold text-[#3E3E3E] leading-none">Ingia</h1>
            {isInstructor && (
              <span className="flex items-center gap-1 px-2 py-0.5 bg-[#F3C6CF] text-white rounded-full text-[8px] font-bold uppercase tracking-tighter">
                <ShieldCheck size={8} /> Staff
              </span>
            )}
          </div>
          <p className="text-[10px] text-[#3E3E3E] opacity-70 italic">With you, mama</p>
        </div>
      </div>
      
      <div className="flex items-center gap-2">
        <button 
          onClick={onOpenNotifications}
          className="p-2 text-[#3E3E3E] hover:bg-white/40 rounded-full transition-colors relative"
        >
          <Bell size={20} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#F7B7A3] rounded-full border border-white"></span>
        </button>
        <button 
          onClick={onOpenSettings}
          className="p-2 text-[#3E3E3E] hover:bg-white/40 rounded-full transition-colors"
        >
          <Settings size={20} />
        </button>
      </div>
    </header>
  );
};

export default Header;
